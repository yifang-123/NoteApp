# CI / GitHub Actions

This project includes a GitHub Actions workflow that automatically builds the app on every push and pull request.

## Workflow: `.github/workflows/android.yml`

### Triggers
- Push to `main`, `master`, or `develop` branches
- Pull requests targeting `main` or `master`

### Jobs
1. **Checkout** — Clones the repository
2. **Setup JDK 17** — Uses Eclipse Temurin 17
3. **Setup Gradle** — Installs Gradle 8.5
4. **Grant execute permission** — `chmod +x ./gradlew`
5. **Create local.properties** — Auto-generates from `$ANDROID_HOME`
6. **Accept SDK licenses** — `sdkmanager --licenses`
7. **Build Debug APK** — `./gradlew assembleDebug`
8. **Upload APK** — Artifact name: `noteapp-debug-apk`
9. **Run Lint** — `./gradlew lintDebug` (non-blocking)

### Required GitHub Secrets

None! The workflow uses GitHub Actions' built-in `ANDROID_HOME` environment variable and the public Android SDK packages.

### How to Download the APK

1. Go to your repo → **Actions** tab
2. Click on the latest workflow run
3. Scroll down to **Artifacts**
4. Download `noteapp-debug-apk`

### Local Build

```bash
# Clone
git clone https://github.com/your-username/NoteApp.git
cd NoteApp

# Set SDK path (Linux/macOS)
echo "sdk.dir=$HOME/Android/Sdk" > local.properties

# Build
./gradlew assembleDebug

# Install to device
./gradlew installDebug
```

### Troubleshooting

| Error | Solution |
|-------|-----------|
| `SDK location not found` | Create `local.properties` with `sdk.dir=...` |
| `Failed to install the following SDK packages` | Workflow will auto-accept licenses |
| `OutOfMemoryError` | Increase heap in `gradle.properties` |
| `SQLCipher native lib not found` | Run `./gradlew clean` and rebuild |
