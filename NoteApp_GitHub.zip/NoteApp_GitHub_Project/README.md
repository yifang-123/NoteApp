# NoteApp — 安全笔记应用

[![Android CI](https://github.com/your-username/NoteApp/actions/workflows/android.yml/badge.svg)](https://github.com/your-username/NoteApp/actions/workflows/android.yml)
[![License: MIT](https://img.shields.io/badge/License-MIT-yellow.svg)](https://opensource.org/licenses/MIT)
[![Min SDK](https://img.shields.io/badge/Min%20SDK-26-brightgreen)](https://developer.android.com/about/versions)
[![Kotlin](https://img.shields.io/badge/Kotlin-1.9.22-blue)](https://kotlinlang.org)
[![Compose BOM](https://img.shields.io/badge/Compose%20BOM-2024.02.00-purple)](https://developer.android.com/jetpack/androidx/releases/compose)

一款基于 Jetpack Compose + Hilt + Room 的 Android 安全笔记应用，支持富文本块编辑、加密附件预览、桌面小组件等功能。

---

## ✨ 功能特性

### 📝 编辑器
- **8 种内容块**：文本、标题(1-6级)、无序列表、有序列表、待办清单、代码块、附件、思维导图
- **拖拽排序**：长按拖拽手柄调整块顺序，支持撤销/重做
- **撤销/重做**：完整的命令模式实现，所有操作可撤销
- **网格/列表双视图**：一键切换编辑布局
- **自定义块尺寸**：拖拽右下角调整每个块的大小

### 🔒 安全
- **SQLCipher 加密数据库**：笔记内容全程加密存储
- **AndroidX Security 加密附件**：AES-256-GCM 加密，MasterKey 保护
- **EncryptedSharedPreferences**：敏感配置（数据库密码）安全存储

### 📎 附件系统
- **多文件选择**：一次添加多个附件
- **内嵌预览**：
  - 🖼️ 图片 — Coil 加载缩略图
  - 📄 PDF — PdfRenderer 多页翻页浏览
  - 📝 文本/代码 — 截断显示前 500 字符
  - 🎵 音频 — ExoPlayer 内嵌播放（进度条/播放暂停）
  - 🎬 视频 — ExoPlayer 内嵌播放
  - 📊 Office 文件 — 提示 + 「用其他应用打开」
- **异步缩略图**：后台线程解码 + LruCache 内存缓存
- **文件分享**：FileProvider 安全分享

### 🔍 搜索与标签
- **全文搜索**：FTS4 索引（含附件文件名）
- **标签管理**：为笔记添加/移除标签，按标签筛选
- **回收站**：软删除 + 永久删除 + 恢复

### 📱 桌面小组件
- Glance 实现的笔记小组件
- 显示最近 3 条笔记
- 点击新建跳转应用

---

## 🏗️ 技术栈

| 层级 | 技术 |
|---|---|
| UI | Jetpack Compose (BOM 2024.02.00) + Material 3 |
| 架构 | MVVM + MVI（单向数据流） |
| 依赖注入 | Hilt 2.50 |
| 本地数据库 | Room 2.6.1 + SQLCipher 4.5.4 |
| 后台任务 | WorkManager 2.9.0 |
| 媒体播放 | Media3 ExoPlayer 1.2.1 |
| 图片加载 | Coil 2.5.0 |
| 加密 | AndroidX Security Crypto 1.1.0 + SQLCipher |
| 小组件 | Glance 1.0.0 |
| 序列化 | kotlinx-serialization 1.6.2 |
| 构建 | Gradle 8.5 + Kotlin 1.9.22 + JDK 17 |

---

## 📂 项目结构

```
app/src/main/java/com/example/noteapp/
├── MainActivity.kt              # 导航宿主
├── NoteApp.kt                   # Application 入口
├── data/
│   ├── local/                   # Room 实体 + DAO
│   │   ├── Note.kt
│   │   ├── NoteDao.kt
│   │   ├── NoteDatabase.kt
│   │   ├── NoteFts.kt
│   │   ├── NoteTagCrossRef.kt
│   │   ├── Tag.kt
│   │   └── TagDao.kt
│   └── repository/
│       └── NoteRepository.kt    # 数据仓库
├── di/
│   └── AppModule.kt            # Hilt 依赖注入
├── domain/
│   └── command/                # 命令模式（撤销/重做）
│       ├── CommandManager.kt
│       └── EditorBlocksState.kt
├── ui/
│   ├── component/              # 可复用 UI 组件
│   │   ├── NoteCard.kt
│   │   └── AttachmentCard.kt
│   ├── screen/                 # 页面
│   │   ├── BlockModel.kt       # 块数据模型 + JSON 序列化
│   │   ├── EditorScreen.kt     # 编辑器主界面
│   │   ├── AttachmentPreviewScreen.kt  # 全屏预览
│   │   ├── MainScreen.kt       # 主列表页
│   │   ├── TrashScreen.kt      # 回收站
│   │   ├── VideoPlayer.kt      # 视频播放器
│   │   ├── AudioPlayer.kt      # 音频播放器
│   │   └── PdfPager.kt         # PDF 多页浏览
│   ├── theme/
│   │   └── Theme.kt            # 主题（亮/暗色）
│   └── viewmodel/
│       ├── NoteViewModel.kt     # 主 ViewModel
│       └── EditorViewModel.kt   # 编辑器 ViewModel
├── util/                       # 工具类
│   ├── FileEncryptionUtil.kt   # 文件加密/解密
│   ├── ThumbnailCache.kt       # 缩略图缓存
│   └── ShareHelper.kt          # 文件分享
└── widget/                     # 桌面小组件
    ├── NoteWidget.kt
    ├── WidgetUpdateWorker.kt
    └── CleanupWorker.kt        # 临时文件清理
```

---

## 🚀 编译运行

### 环境要求

- **JDK 17**（推荐 Eclipse Temurin）
- **Android SDK 34**
- **Android Studio Hedgehog+**（推荐）
- **Gradle 8.5**（项目自带 wrapper）

### 本地编译

```bash
# 1. 克隆项目
git clone https://github.com/your-username/NoteApp.git
cd NoteApp

# 2. 确保 local.properties 指向你的 SDK
echo "sdk.dir=/path/to/your/Android/Sdk" > local.properties

# 3. 编译 Debug APK
./gradlew assembleDebug

# 4. 安装到设备
./gradlew installDebug
```

### GitHub Actions 自动编译

项目已配置 GitHub Actions CI（`.github/workflows/android.yml`），每次 push 到 `main`/`master` 分支或提交 PR 时会自动：

1. ✅ 检出代码
2. ✅ 安装 JDK 17 + Gradle 8.5
3. ✅ 接受 Android SDK 许可证
4. ✅ 编译 Debug APK
5. ✅ 上传 APK 为 Artifact
6. ✅ 运行 Lint 检查

编译产物可在 GitHub 仓库的 **Actions** 标签页下载。

---

## 🔧 已知问题与解决方案

| 问题 | 解决方案 |
|---|---|
| GitHub Actions 中 `sdk.dir` 缺失 | CI 脚本自动从 `$ANDROID_HOME` 生成 `local.properties` |
| SQLCipher 需要 NDK | 项目已配置 `net.zetetic:android-database-sqlcipher:4.5.4`，自动下载 native 库 |
| 首次编译慢 | Gradle 已开启 `org.gradle.caching=true` + 并行构建 + 守护进程 |
| 内存不足 | `gradle.properties` 设置 `-Xmx2048m` |

---

## 📄 License

MIT License — 详见 [LICENSE](LICENSE) 文件。

---

## 🙏 致谢

- [Jetpack Compose](https://developer.android.com/jetpack/compose)
- [AndroidX Security](https://developer.android.com/topic/security/data)
- [SQLCipher for Android](https://www.zetetic.net/sqlcipher/)
- [ExoPlayer (Media3)](https://developer.android.com/media/media3)
- [Coil](https://coil-kt.github.io/coil/)
- [Dagger Hilt](https://dagger.dev/hilt/)
