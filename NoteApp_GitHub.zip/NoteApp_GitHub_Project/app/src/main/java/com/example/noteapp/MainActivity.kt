package com.example.noteapp

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.navigation.NavType
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import androidx.navigation.navArgument
import com.example.noteapp.ui.screen.*
import com.example.noteapp.ui.theme.NoteAppTheme
import com.example.noteapp.ui.viewmodel.NoteViewModel
import dagger.hilt.android.AndroidEntryPoint

@AndroidEntryPoint
class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            NoteAppTheme {
                Surface(
                    modifier = Modifier.fillMaxSize(),
                    color = MaterialTheme.colorScheme.background
                ) {
                    NoteNavHost()
                }
            }
        }
    }
}

@Composable
fun NoteNavHost() {
    val navController = rememberNavController()
    val viewModel: NoteViewModel = viewModel()
    NavHost(navController = navController, startDestination = "main") {
        composable("main") {
            MainScreen(
                viewModel = viewModel,
                onNoteClick = { id -> navController.navigate("editor/$id") },
                onAddNote = { navController.navigate("editor/0") },
                onTrashClick = { navController.navigate("trash") }
            )
        }
        composable("trash") {
            TrashScreen(
                viewModel = viewModel,
                onBack = { navController.popBackStack() }
            )
        }
        composable(
            "editor/{noteId}",
            arguments = listOf(navArgument("noteId") { type = NavType.LongType })
        ) { backStackEntry ->
            val noteId = backStackEntry.arguments?.getLong("noteId") ?: 0L
            EditorScreen(
                noteId = noteId,
                onBack = { navController.popBackStack() },
                onPreview = { path, type ->
                    navController.currentBackStackEntry?.savedStateHandle
                        ?.set("preview_path", path)
                    navController.currentBackStackEntry?.savedStateHandle
                        ?.set("preview_type", type)
                    navController.navigate("preview")
                }
            )
        }
        composable("preview") { backStackEntry ->
            val path = backStackEntry.savedStateHandle.get<String>("preview_path") ?: ""
            val type = backStackEntry.savedStateHandle.get<String>("preview_type") ?: ""
            AttachmentPreviewScreen(
                filePath = path,
                fileType = type,
                onBack = { navController.popBackStack() }
            )
        }
    }
}
