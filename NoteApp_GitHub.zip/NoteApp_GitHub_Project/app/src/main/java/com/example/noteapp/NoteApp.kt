package com.example.noteapp

import android.app.Application
import com.example.noteapp.util.FileEncryptionUtil
import com.example.noteapp.widget.CleanupWorker
import com.example.noteapp.widget.WidgetUpdateWorker
import dagger.hilt.android.HiltAndroidApp

@HiltAndroidApp
class NoteApp : Application() {

    override fun onCreate() {
        super.onCreate()

        // 启动桌面小组件定期更新
        WidgetUpdateWorker.enqueuePeriodic(this)

        // 启动临时文件每日清理任务
        CleanupWorker.enqueuePeriodic(this)

        // 应用启动时执行一次清理（兜底）
        FileEncryptionUtil.cleanExpiredTempFiles(this, maxAgeMs = 24 * 60 * 60 * 1000L)
    }
}
