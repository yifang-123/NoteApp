package com.example.noteapp.data.local

import androidx.room.Entity
import androidx.room.Index
import androidx.room.PrimaryKey

@Entity(
    tableName = "notes",
    indices = [
        Index("isDeleted"),
        Index("timestamp"),
        Index("deletedTime")
    ]
)
data class Note(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val title: String = "",
    val content: String = "",
    val previewText: String = "",
    val isDeleted: Boolean = false,
    val timestamp: Long = System.currentTimeMillis(),
    val deletedTime: Long = 0L
)
