package com.example.noteapp.data.local

import androidx.room.*
import kotlinx.coroutines.flow.Flow

@Dao
interface NoteDao {

    @Query("SELECT * FROM notes WHERE isDeleted = 0 ORDER BY timestamp DESC")
    fun getAllNotes(): Flow<List<Note>>

    @Query("SELECT * FROM notes WHERE isDeleted = 1 ORDER BY deletedTime DESC")
    fun getDeletedNotes(): Flow<List<Note>>

    @Query("SELECT * FROM notes WHERE isDeleted = 0 ORDER BY timestamp DESC LIMIT 3")
    suspend fun getRecentNotes(): List<Note>

    @Transaction
    @Query("SELECT * FROM notes WHERE isDeleted = 0 ORDER BY timestamp DESC LIMIT 3")
    fun getRecentNotesFlow(): Flow<List<Note>>

    @Query("SELECT * FROM notes WHERE id = :id")
    suspend fun getNoteById(id: Long): Note?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertNote(note: Note): Long

    @Update
    suspend fun updateNote(note: Note)

    @Query("DELETE FROM notes WHERE id = :id")
    suspend fun deleteById(id: Long)

    @Query("DELETE FROM notes_fts WHERE rowid = :noteId")
    suspend fun deleteFts(noteId: Long)

    @Query("INSERT INTO notes_fts(rowid, title, content) VALUES (:id, :title, :content)")
    suspend fun insertFts(id: Long, title: String, content: String)

    @Query("UPDATE notes_fts SET title = :title, content = :content WHERE rowid = :id")
    suspend fun updateFts(id: Long, title: String, content: String)

    @Query("""
        SELECT notes.* FROM notes
        JOIN notes_fts ON notes.id = notes_fts.rowid
        WHERE notes_fts MATCH :query AND notes.isDeleted = 0
        ORDER BY notes.timestamp DESC
    """)
    suspend fun searchNotes(query: String): List<Note>
}
