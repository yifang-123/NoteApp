package com.example.noteapp.data.local

import androidx.room.Database
import androidx.room.RoomDatabase

@Database(
    entities = [
        Note::class,
        NoteFts::class,
        Tag::class,
        NoteTagCrossRef::class
    ],
    version = 1,
    exportSchema = true
)
abstract class NoteDatabase : RoomDatabase() {
    abstract fun noteDao(): NoteDao
    abstract fun tagDao(): TagDao
}
