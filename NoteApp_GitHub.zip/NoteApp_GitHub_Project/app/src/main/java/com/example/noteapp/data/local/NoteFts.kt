package com.example.noteapp.data.local

import androidx.room.Entity
import androidx.room.Fts4

@Fts4(contentEntity = Note::class, tokenizer = "unicode61")
@Entity(tableName = "notes_fts")
data class NoteFts(
    val title: String,
    val content: String
)
