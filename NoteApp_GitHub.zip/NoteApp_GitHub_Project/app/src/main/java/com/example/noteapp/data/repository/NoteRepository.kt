package com.example.noteapp.data.repository

import android.content.Context
import android.util.Log
import com.example.noteapp.data.local.*
import com.example.noteapp.widget.WidgetUpdateWorker
import dagger.hilt.android.qualifiers.ApplicationContext
import kotlinx.coroutines.flow.Flow
import org.json.JSONArray
import org.json.JSONObject
import javax.inject.Inject

class NoteRepository @Inject constructor(
    private val noteDao: NoteDao,
    private val tagDao: TagDao,
    @ApplicationContext private val context: Context
) {
    companion object {
        private const val TAG = "NoteRepository"
    }

    val allNotes: Flow<List<Note>> = noteDao.getAllNotes()
    val deletedNotes: Flow<List<Note>> = noteDao.getDeletedNotes()
    val recentNotes: Flow<List<Note>> = noteDao.getRecentNotesFlow()

    suspend fun getRecentNotes(): List<Note> = noteDao.getRecentNotes()

    // ================================================================
    // 笔记 CRUD
    // ================================================================
    suspend fun insert(note: Note): Long {
        return try {
            val id = noteDao.insertNote(note)
            noteDao.insertFts(id, note.title, plainTextFromJson(note.content))
            WidgetUpdateWorker.enqueueImmediate(context)
            id
        } catch (e: Exception) {
            Log.e(TAG, "insert failed", e)
            -1L
        }
    }

    suspend fun update(note: Note) {
        try {
            noteDao.updateNote(note)
            noteDao.updateFts(note.id, note.title, plainTextFromJson(note.content))
            WidgetUpdateWorker.enqueueImmediate(context)
        } catch (e: Exception) {
            Log.e(TAG, "update failed for note ${note.id}", e)
        }
    }

    suspend fun deleteById(id: Long) {
        try {
            noteDao.deleteById(id)
            noteDao.deleteFts(id)
            tagDao.deleteAllCrossRefsForNote(id)
            WidgetUpdateWorker.enqueueImmediate(context)
        } catch (e: Exception) {
            Log.e(TAG, "deleteById failed for id $id", e)
        }
    }

    suspend fun getNoteById(id: Long): Note? {
        return try {
            noteDao.getNoteById(id)
        } catch (e: Exception) {
            Log.e(TAG, "getNoteById failed for id $id", e)
            null
        }
    }

    suspend fun searchNotes(query: String): List<Note> {
        return try {
            noteDao.searchNotes(query)
        } catch (e: Exception) {
            Log.e(TAG, "searchNotes failed for query '$query'", e)
            emptyList()
        }
    }

    // ================================================================
    // 标签
    // ================================================================
    suspend fun addTagToNote(noteId: Long, tagName: String) {
        try {
            val tagId = tagDao.insertTag(Tag(name = tagName))
            tagDao.insertCrossRef(NoteTagCrossRef(noteId = noteId, tagId = tagId))
        } catch (e: Exception) {
            Log.e(TAG, "addTagToNote failed: noteId=$noteId, tag=$tagName", e)
        }
    }

    suspend fun removeTagFromNote(noteId: Long, tagName: String) {
        try {
            val tags = tagDao.getTagsForNote(noteId)
            val target = tags.find { it.name == tagName }
            if (target != null) {
                tagDao.deleteCrossRefByNoteAndTag(noteId, target.id)
            }
        } catch (e: Exception) {
            Log.e(TAG, "removeTagFromNote failed: noteId=$noteId, tag=$tagName", e)
        }
    }

    fun getAllTagsFlow(): Flow<List<Tag>> = tagDao.getAllTagsFlow()

    fun getNotesByTagFlow(tagId: Long): Flow<List<Note>> = tagDao.getNotesByTagFlow(tagId)

    suspend fun addTagToNotes(noteIds: List<Long>, tagName: String) {
        try {
            val tagId = tagDao.insertTag(Tag(name = tagName))
            noteIds.forEach { id ->
                tagDao.insertCrossRef(NoteTagCrossRef(noteId = id, tagId = tagId))
            }
        } catch (e: Exception) {
            Log.e(TAG, "addTagToNotes failed: tag=$tagName, notes=$noteIds", e)
        }
    }

    suspend fun getTagsForNote(noteId: Long): List<Tag> {
        return try {
            tagDao.getTagsForNote(noteId)
        } catch (e: Exception) {
            Log.e(TAG, "getTagsForNote failed for noteId=$noteId", e)
            emptyList()
        }
    }

    // ================================================================
    // 批量回收站操作
    // ================================================================
    suspend fun moveNotesToTrash(noteIds: List<Long>) {
        noteIds.forEach { id ->
            try {
                val note = noteDao.getNoteById(id) ?: return@forEach
                update(note.copy(isDeleted = true, deletedTime = System.currentTimeMillis()))
            } catch (e: Exception) {
                Log.e(TAG, "moveNotesToTrash failed for id $id", e)
            }
        }
    }

    suspend fun deleteNotesPermanently(noteIds: List<Long>) {
        noteIds.forEach { id ->
            try { deleteById(id) } catch (e: Exception) {
                Log.e(TAG, "deleteNotesPermanently failed for id $id", e)
            }
        }
    }

    suspend fun restoreNotes(noteIds: List<Long>) {
        noteIds.forEach { id ->
            try {
                val note = noteDao.getNoteById(id) ?: return@forEach
                update(note.copy(isDeleted = false, deletedTime = 0L))
            } catch (e: Exception) {
                Log.e(TAG, "restoreNotes failed for id $id", e)
            }
        }
    }

    // ================================================================
    // FTS 工具 —— 包含附件文件名
    // ================================================================
    private fun plainTextFromJson(content: String): String {
        return try {
            val sb = StringBuilder()
            val arr = JSONArray(content)
            for (i in 0 until arr.length()) {
                val obj = arr.getJSONObject(i)
                when (obj.optString("type")) {
                    "text", "heading" -> sb.append(obj.optString("text", "")).append("\n")
                    "bullet_list", "numbered_list" -> {
                        val items = obj.optJSONArray("items")
                        if (items != null) for (j in 0 until items.length()) {
                            sb.append(items.getString(j)).append("\n")
                        }
                    }
                    "todo" -> {
                        val items = obj.optJSONArray("items")
                        if (items != null) for (j in 0 until items.length()) {
                            val item = items.getJSONObject(j)
                            sb.append(
                                if (item.optBoolean("completed")) "[x] "
                                else "[ ] "
                            ).append(item.optString("text")).append("\n")
                        }
                    }
                    "code" -> sb.append(obj.optString("code")).append("\n")
                    "attachment" -> {
                        // 附件文件名也进入 FTS 索引
                        sb.append(obj.optString("name")).append("\n")
                    }
                    "mindmap" -> sb.append(obj.optString("title")).append("\n")
                }
            }
            sb.toString()
        } catch (e: Exception) {
            Log.e(TAG, "plainTextFromJson failed", e)
            content
        }
    }
}
