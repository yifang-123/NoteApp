package com.example.noteapp.di

import android.content.Context
import androidx.room.Room
import com.example.noteapp.data.local.NoteDatabase
import com.example.noteapp.data.local.NoteDao
import com.example.noteapp.data.local.TagDao
import com.example.noteapp.data.repository.NoteRepository
import dagger.Module
import dagger.Provides
import dagger.hilt.InstallIn
import dagger.hilt.android.qualifiers.ApplicationContext
import dagger.hilt.components.SingletonComponent
import net.sqlcipher.database.SupportFactory
import java.security.SecureRandom
import javax.inject.Singleton

@Module
@InstallIn(SingletonComponent::class)
object AppModule {

    private const val PREFS_NAME = "note_db_config"
    private const val DB_PASSPHRASE_KEY = "db_passphrase"

    @Provides
    @Singleton
    fun provideDatabase(@ApplicationContext context: Context): NoteDatabase {
        val passphrase = getOrCreateDbPassphrase(context)
        val factory = SupportFactory(passphrase.toByteArray())
        return Room.databaseBuilder(
            context,
            NoteDatabase::class.java,
            "note_database.db"
        )
            .openHelperFactory(factory)
            .fallbackToDestructiveMigration()
            .build()
    }

    @Provides
    fun provideNoteDao(database: NoteDatabase): NoteDao = database.noteDao()

    @Provides
    fun provideTagDao(database: NoteDatabase): TagDao = database.tagDao()

    @Provides
    @Singleton
    fun provideNoteRepository(
        noteDao: NoteDao,
        tagDao: TagDao,
        @ApplicationContext context: Context
    ): NoteRepository {
        return NoteRepository(noteDao, tagDao, context)
    }

    private fun getOrCreateDbPassphrase(context: Context): String {
        val prefs = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
        return prefs.getString(DB_PASSPHRASE_KEY, null) ?: run {
            val newPassphrase = generateRandomPassphrase()
            prefs.edit().putString(DB_PASSPHRASE_KEY, newPassphrase).apply()
            newPassphrase
        }
    }

    private fun generateRandomPassphrase(): String {
        val bytes = ByteArray(32)
        SecureRandom().nextBytes(bytes)
        return bytes.joinToString("") { "%02x".format(it) }
    }
}
