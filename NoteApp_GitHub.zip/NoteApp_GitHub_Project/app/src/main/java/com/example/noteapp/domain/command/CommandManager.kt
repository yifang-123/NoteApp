package com.example.noteapp.domain.command

import com.example.noteapp.ui.screen.*

/**
 * 命令管理器 —— 支持撤销/重做
 *
 * 核心原则：所有命令通过**替换整个 BlockState 对象**来工作，
 * 而不是直接修改对象内部属性，确保 Compose 能正确感知状态变化并重组 UI。
 */
class CommandManager {
    private val _undoStack = mutableListOf<EditorCommand>()
    private val _redoStack = mutableListOf<EditorCommand>()

    fun execute(command: EditorCommand, state: EditorBlocksState) {
        command.execute(state)
        _undoStack.add(command)
        _redoStack.clear()
    }

    fun undo(state: EditorBlocksState): Boolean {
        val cmd = _undoStack.lastOrNull() ?: return false
        cmd.undo(state)
        _undoStack.removeLast()
        _redoStack.add(cmd)
        return true
    }

    fun redo(state: EditorBlocksState): Boolean {
        val cmd = _redoStack.lastOrNull() ?: return false
        cmd.execute(state)
        _redoStack.removeLast()
        _undoStack.add(cmd)
        return true
    }

    fun canUndo(): Boolean = _undoStack.isNotEmpty()
    fun canRedo(): Boolean = _redoStack.isNotEmpty()

    fun clear() {
        _undoStack.clear()
        _redoStack.clear()
    }
}

enum class FormatType { BOLD, ITALIC }

/**
 * 所有编辑器命令的密封基类
 */
sealed class EditorCommand {
    abstract fun execute(state: EditorBlocksState)
    abstract fun undo(state: EditorBlocksState)

    // ─── 块操作 ───────────────────────────────────
    data class InsertBlock(val index: Int, val blockState: BlockState) : EditorCommand() {
        override fun execute(state: EditorBlocksState) {
            state.addBlock(index, blockState)
        }
        override fun undo(state: EditorBlocksState) {
            state.removeBlock(index)
        }
    }

    data class DeleteBlock(val index: Int, val blockState: BlockState) : EditorCommand() {
        override fun execute(state: EditorBlocksState) {
            state.removeBlock(index)
        }
        override fun undo(state: EditorBlocksState) {
            state.addBlock(index, blockState)
        }
    }

    data class MoveBlock(
        val fromIndex: Int,
        val toIndex: Int,
        private var _movedId: Long = -1L
    ) : EditorCommand() {
        override fun execute(state: EditorBlocksState) {
            _movedId = state.moveBlock(fromIndex, toIndex)
        }
        override fun undo(state: EditorBlocksState) {
            // 反向移动
            val currentIdx = state.blockIds.indexOf(_movedId)
            if (currentIdx >= 0) {
                state.moveBlock(currentIdx, fromIndex)
            }
        }
    }

    // ─── 文本更新（核心修复：替换整个对象） ────────
    data class UpdateText(
        val index: Int,
        val oldText: String,
        val newText: String
    ) : EditorCommand() {
        override fun execute(state: EditorBlocksState) {
            val oldState = state.blockStates[index]
            val newState = when (oldState) {
                is TextBlockState -> oldState.copy(text = newText)
                is HeadingBlockState -> oldState.copy(text = newText)
                is CodeBlockState -> oldState.copy(code = newText)
                else -> return
            }
            state.replaceBlock(index, newState)
        }

        override fun undo(state: EditorBlocksState) {
            val oldState = state.blockStates[index]
            val restored = when (oldState) {
                is TextBlockState -> oldState.copy(text = oldText)
                is HeadingBlockState -> oldState.copy(text = oldText)
                is CodeBlockState -> oldState.copy(code = oldText)
                else -> return
            }
            state.replaceBlock(index, restored)
        }
    }

    // ─── 格式切换 ──────────────────────────────────
    data class ToggleFormat(
        val index: Int,
        val format: FormatType,
        val oldValue: Boolean,
        val newValue: Boolean
    ) : EditorCommand() {
        override fun execute(state: EditorBlocksState) {
            val s = state.blockStates[index] as? TextBlockState ?: return
            val newState = when (format) {
                FormatType.BOLD -> s.copy(isBold = newValue)
                FormatType.ITALIC -> s.copy(isItalic = newValue)
            }
            state.replaceBlock(index, newState)
        }

        override fun undo(state: EditorBlocksState) {
            val s = state.blockStates[index] as? TextBlockState ?: return
            val restored = when (format) {
                FormatType.BOLD -> s.copy(isBold = oldValue)
                FormatType.ITALIC -> s.copy(isItalic = oldValue)
            }
            state.replaceBlock(index, restored)
        }
    }

    // ─── 列表项更新 ────────────────────────────────
    data class UpdateListItem(
        val blockIndex: Int,
        val itemIndex: Int,
        val oldValue: String,
        val newValue: String
    ) : EditorCommand() {
        override fun execute(state: EditorBlocksState) {
            val block = state.blockStates[blockIndex]
            when (block) {
                is BulletListBlockState -> {
                    val newItems = block.items.toMutableList().also { it[itemIndex] = newValue }
                    state.replaceBlock(blockIndex, block.copy(items = newItems))
                }
                is NumberedListBlockState -> {
                    val newItems = block.items.toMutableList().also { it[itemIndex] = newValue }
                    state.replaceBlock(blockIndex, block.copy(items = newItems))
                }
                else -> {}
            }
        }

        override fun undo(state: EditorBlocksState) {
            val block = state.blockStates[blockIndex]
            when (block) {
                is BulletListBlockState -> {
                    val newItems = block.items.toMutableList().also { it[itemIndex] = oldValue }
                    state.replaceBlock(blockIndex, block.copy(items = newItems))
                }
                is NumberedListBlockState -> {
                    val newItems = block.items.toMutableList().also { it[itemIndex] = oldValue }
                    state.replaceBlock(blockIndex, block.copy(items = newItems))
                }
                else -> {}
            }
        }
    }

    // ─── Todo 项切换 ────────────────────────────────
    data class ToggleTodoItem(
        val blockIndex: Int,
        val itemIndex: Int,
        val oldCompleted: Boolean,
        val newCompleted: Boolean
    ) : EditorCommand() {
        override fun execute(state: EditorBlocksState) {
            val s = state.blockStates[blockIndex] as? TodoBlockState ?: return
            if (itemIndex < s.items.size) {
                val newItems = s.items.toMutableList().also {
                    it[itemIndex] = it[itemIndex].copy(isCompleted = newCompleted)
                }
                state.replaceBlock(blockIndex, s.copy(items = newItems))
            }
        }

        override fun undo(state: EditorBlocksState) {
            val s = state.blockStates[blockIndex] as? TodoBlockState ?: return
            if (itemIndex < s.items.size) {
                val newItems = s.items.toMutableList().also {
                    it[itemIndex] = it[itemIndex].copy(isCompleted = oldCompleted)
                }
                state.replaceBlock(blockIndex, s.copy(items = newItems))
            }
        }
    }

    // ─── 标题级别更新 ────────────────────────────────
    data class UpdateHeadingLevel(
        val index: Int,
        val oldLevel: Int,
        val newLevel: Int
    ) : EditorCommand() {
        override fun execute(state: EditorBlocksState) {
            val s = state.blockStates[index] as? HeadingBlockState ?: return
            state.replaceBlock(index, s.copy(level = newLevel))
        }

        override fun undo(state: EditorBlocksState) {
            val s = state.blockStates[index] as? HeadingBlockState ?: return
            state.replaceBlock(index, s.copy(level = oldLevel))
        }
    }
}
