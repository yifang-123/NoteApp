package com.example.noteapp.domain.command

import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.MutableIntState
import com.example.noteapp.ui.screen.BlockState
import java.util.concurrent.atomic.AtomicLong

/**
 * 编辑器块状态容器
 *
 * - blockStates: 可观察的块列表（替换元素会触发重组）
 * - blockIds: 每个块的唯一 ID（用于 LazyColumn/Grid 的 key）
 * - version: 递增版本号（驱动派生状态刷新）
 */
class EditorBlocksState {

    private val nextId = AtomicLong(1)

    val blockStates = mutableStateListOf<BlockState>()
    val blockIds = mutableStateListOf<Long>()
    val version: MutableIntState = mutableIntStateOf(0)

    fun addBlock(index: Int, state: BlockState): Long {
        val id = nextId.getAndIncrement()
        blockStates.add(index, state)
        blockIds.add(index, id)
        version.intValue++
        return id
    }

    fun removeBlock(index: Int): Long {
        val id = blockIds[index]
        blockStates.removeAt(index)
        blockIds.removeAt(index)
        version.intValue++
        return id
    }

    /**
     * 移动块位置（拖拽排序用）
     * @return 被移动块的 ID
     */
    fun moveBlock(fromIndex: Int, toIndex: Int): Long {
        if (fromIndex < 0 || fromIndex >= blockStates.size) return -1
        if (toIndex < 0 || toIndex >= blockStates.size) return -1
        if (fromIndex == toIndex) return blockIds[fromIndex]

        val state = blockStates.removeAt(fromIndex)
        val id = blockIds.removeAt(fromIndex)
        blockStates.add(toIndex, state)
        blockIds.add(toIndex, id)
        version.intValue++
        return id
    }

    /**
     * 替换指定位置的块（用于命令模式的 undo/redo）
     * 这是核心方法 —— 通过替换整个对象来触发 Compose 重组
     */
    fun replaceBlock(index: Int, newState: BlockState) {
        if (index < 0 || index >= blockStates.size) return
        // 保留尺寸信息
        newState.blockWidth = blockStates[index].blockWidth
        newState.blockHeight = blockStates[index].blockHeight
        blockStates[index] = newState
        version.intValue++
    }

    fun getBlockId(index: Int): Long = blockIds.getOrElse(index) { -1L }

    fun clear() {
        blockStates.clear()
        blockIds.clear()
        version.intValue++
    }
}
