package com.example.noteapp.ui.screen

import android.widget.Toast
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.painter.BitmapPainter
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.rememberAsyncImagePainter
import com.example.noteapp.util.FileEncryptionUtil
import com.example.noteapp.util.ShareHelper
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.File

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AttachmentPreviewScreen(
    filePath: String,
    fileType: String,
    onBack: () -> Unit
) {
    val context = LocalContext.current

    // 独立解密通道
    var decryptedPath by remember { mutableStateOf<String?>(null) }
    var isLoading by remember { mutableStateOf(true) }
    var loadError by remember { mutableStateOf<String?>(null) }

    LaunchedEffect(filePath) {
        isLoading = true
        loadError = null
        val result = withContext(Dispatchers.IO) {
            try {
                FileEncryptionUtil.decryptToTemp(context, filePath)
            } catch (e: Exception) {
                null
            }
        }
        if (result != null) {
            decryptedPath = result
        } else {
            loadError = "解密失败，请重试"
        }
        isLoading = false
    }

    // 独立清理：仅清理本次全屏预览的临时文件
    DisposableEffect(Unit) {
        onDispose {
            decryptedPath?.let { path ->
                try {
                    File(path).delete()
                } catch (_: Exception) {}
            }
        }
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("预览") },
                navigationIcon = {
                    IconButton(onClick = onBack) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, "返回")
                    }
                },
                actions = {
                    // 分享按钮
                    IconButton(onClick = {
                        decryptedPath?.let { path ->
                            val success = ShareHelper.shareFile(context, path, fileType)
                            if (!success) {
                                Toast.makeText(context, "分享失败：未找到可用应用", Toast.LENGTH_SHORT).show()
                            }
                        }
                    }) {
                        Icon(Icons.Default.Share, "分享")
                    }
                    // 用其他应用打开（Office 等）
                    IconButton(onClick = {
                        decryptedPath?.let { path ->
                            val success = ShareHelper.openWithOtherApp(context, path, fileType)
                            if (!success) {
                                Toast.makeText(context, "未找到可打开此文件的应用", Toast.LENGTH_SHORT).show()
                            }
                        }
                    }) {
                        Icon(Icons.Default.OpenInNew, "用其他应用打开")
                    }
                }
            )
        }
    ) { padding ->
        when {
            isLoading -> {
                Box(Modifier.fillMaxSize().padding(padding), contentAlignment = Alignment.Center) {
                    CircularProgressIndicator()
                }
            }
            loadError != null -> {
                Box(Modifier.fillMaxSize().padding(padding), contentAlignment = Alignment.Center) {
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Icon(
                            Icons.Default.ErrorOutline,
                            contentDescription = null,
                            modifier = Modifier.size(48.dp),
                            tint = MaterialTheme.colorScheme.error
                        )
                        Spacer(Modifier.height(8.dp))
                        Text("预览失败: $loadError", color = MaterialTheme.colorScheme.error)
                        Spacer(Modifier.height(8.dp))
                        Button(onClick = onBack) { Text("返回") }
                    }
                }
            }
            decryptedPath != null -> {
                val path = decryptedPath!!
                when {
                    fileType.startsWith("image/") -> {
                        Image(
                            painter = rememberAsyncImagePainter(model = File(path)),
                            contentDescription = null,
                            modifier = Modifier.fillMaxSize().padding(padding),
                            contentScale = ContentScale.Fit
                        )
                    }
                    fileType == "application/pdf" -> {
                        PdfPager(
                            pdfPath = path,
                            modifier = Modifier.fillMaxSize().padding(padding)
                        )
                    }
                    fileType.startsWith("audio/") -> {
                        AudioPlayer(
                            filePath = path,
                            fileName = File(path).name,
                            modifier = Modifier.padding(padding)
                        )
                    }
                    fileType.startsWith("video/") -> {
                        VideoPlayer(
                            filePath = path,
                            modifier = Modifier.fillMaxSize().padding(padding)
                        )
                    }
                    fileType.startsWith("text/") ||
                    fileType in listOf("application/json", "application/xml",
                        "application/javascript", "application/x-yaml") -> {
                        TextPreviewFullscreen(path = path, modifier = Modifier.fillMaxSize().padding(padding))
                    }
                    // Office 文件：提示用其他应用打开
                    fileType in listOf(
                        "application/msword",
                        "application/vnd.openxmlformats-officedocument.wordprocessingml.document",
                        "application/vnd.ms-excel",
                        "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
                        "application/vnd.ms-powerpoint",
                        "application/vnd.openxmlformats-officedocument.presentationml.presentation"
                    ) -> {
                        Box(Modifier.fillMaxSize().padding(padding), contentAlignment = Alignment.Center) {
                            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                Icon(
                                    Icons.Default.Description,
                                    contentDescription = null,
                                    modifier = Modifier.size(64.dp),
                                    tint = MaterialTheme.colorScheme.primary
                                )
                                Spacer(Modifier.height(16.dp))
                                Text("Office 文件", style = MaterialTheme.typography.titleMedium)
                                Text(
                                    "系统暂不支持内嵌预览，请使用其他应用打开",
                                    style = MaterialTheme.typography.bodySmall,
                                    color = MaterialTheme.colorScheme.outline
                                )
                                Spacer(Modifier.height(16.dp))
                                Button(onClick = {
                                    val success = ShareHelper.openWithOtherApp(context, path, fileType)
                                    if (!success) {
                                        Toast.makeText(context, "未找到可打开此文件的应用", Toast.LENGTH_SHORT).show()
                                    }
                                }) {
                                    Text("用其他应用打开")
                                }
                            }
                        }
                    }
                    else -> {
                        Box(Modifier.fillMaxSize().padding(padding), contentAlignment = Alignment.Center) {
                            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                Icon(
                                    Icons.Default.InsertDriveFile,
                                    contentDescription = null,
                                    modifier = Modifier.size(64.dp),
                                    tint = MaterialTheme.colorScheme.outline
                                )
                                Spacer(Modifier.height(16.dp))
                                Text("该文件类型暂不支持预览", style = MaterialTheme.typography.bodyLarge)
                                Text("($fileType)", style = MaterialTheme.typography.bodySmall,
                                    color = MaterialTheme.colorScheme.outline)
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun TextPreviewFullscreen(path: String, modifier: Modifier = Modifier) {
    var content by remember(path) { mutableStateOf<String?>(null) }
    var error by remember(path) { mutableStateOf<String?>(null) }

    LaunchedEffect(path) {
        try {
            content = withContext(Dispatchers.IO) {
                File(path).readText()
            }
        } catch (e: Exception) {
            error = "无法读取文件: ${e.message}"
        }
    }

    Box(modifier = modifier) {
        when {
            content != null -> {
                val scrollState = rememberScrollState()
                Text(
                    text = content!!,
                    modifier = Modifier.fillMaxSize().verticalScroll(scrollState).padding(16.dp),
                    fontFamily = FontFamily.Monospace,
                    fontSize = 13.sp,
                    color = MaterialTheme.colorScheme.onSurface
                )
            }
            error != null -> {
                Text(error!!, modifier = Modifier.align(Alignment.Center),
                    color = MaterialTheme.colorScheme.error)
            }
            else -> {
                CircularProgressIndicator(modifier = Modifier.align(Alignment.Center))
            }
        }
    }
}
