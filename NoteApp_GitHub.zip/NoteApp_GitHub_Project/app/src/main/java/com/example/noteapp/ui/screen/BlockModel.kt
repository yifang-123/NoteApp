package com.example.noteapp.ui.screen

import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.snapshots.SnapshotStateList
import org.json.JSONObject
import org.json.JSONArray

// ================================================================
// BlockType 常量
// ================================================================
object BlockType {
    const val TEXT = "text"
    const val HEADING = "heading"
    const val BULLET_LIST = "bullet_list"
    const val NUMBERED_LIST = "numbered_list"
    const val TODO = "todo"
    const val CODE = "code"
    const val ATTACHMENT = "attachment"
    const val MINDMAP = "mindmap"

    fun from(data: BlockData): String = when (data) {
        is BlockData.TextData -> TEXT
        is BlockData.HeadingData -> HEADING
        is BlockData.BulletListData -> BULLET_LIST
        is BlockData.NumberedListData -> NUMBERED_LIST
        is BlockData.TodoData -> TODO
        is BlockData.CodeData -> CODE
        is BlockData.AttachmentData -> ATTACHMENT
        is BlockData.MindMapData -> MINDMAP
    }
}

// ================================================================
// BlockData（数据层，可序列化）
// ================================================================
sealed class BlockData {

    // 可选尺寸（dp），仅在支持自定义尺寸的块类型中使用
    var blockWidth: Float? = null
    var blockHeight: Float? = null

    data class TextData(
        val text: String,
        val isBold: Boolean = false,
        val isItalic: Boolean = false
    ) : BlockData()

    data class HeadingData(
        val level: Int,
        val text: String
    ) : BlockData()

    data class BulletListData(
        val items: List<String>
    ) : BlockData()

    data class NumberedListData(
        val items: List<String>
    ) : BlockData()

    data class TodoData(
        val items: List<TodoItem>
    ) : BlockData()

    data class CodeData(
        val language: String,
        val code: String
    ) : BlockData()

    data class AttachmentData(
        val fileName: String,
        val fileType: String,
        val encryptedRelativePath: String
    ) : BlockData()

    data class MindMapData(
        val title: String,
        val nodes: List<String>
    ) : BlockData()
}

data class TodoItem(val text: String, val isCompleted: Boolean)

// ================================================================
// BlockState（UI 层，持有可变状态）
// ================================================================
sealed class BlockState {
    abstract fun toData(): BlockData

    // 方块尺寸（dp 值），null 表示使用默认尺寸
    var blockWidth: Float? = null
    var blockHeight: Float? = null
}

data class TextBlockState(
    val base: BlockData.TextData,
    var text: String = base.text,
    var isBold: Boolean = base.isBold,
    var isItalic: Boolean = base.isItalic
) : BlockState() {
    override fun toData(): BlockData = BlockData.TextData(text, isBold, isItalic).also {
        it.blockWidth = blockWidth
        it.blockHeight = blockHeight
    }
}

data class HeadingBlockState(
    val base: BlockData.HeadingData,
    var level: Int = base.level,
    var text: String = base.text
) : BlockState() {
    override fun toData(): BlockData = BlockData.HeadingData(level, text).also {
        it.blockWidth = blockWidth
        it.blockHeight = blockHeight
    }
}

data class BulletListBlockState(
    val base: BlockData.BulletListData,
    val items: SnapshotStateList<String> = mutableStateListOf(*base.items.toTypedArray())
) : BlockState() {
    override fun toData(): BlockData = BlockData.BulletListData(items.toList()).also {
        it.blockWidth = blockWidth
        it.blockHeight = blockHeight
    }
}

data class NumberedListBlockState(
    val base: BlockData.NumberedListData,
    val items: SnapshotStateList<String> = mutableStateListOf(*base.items.toTypedArray())
) : BlockState() {
    override fun toData(): BlockData = BlockData.NumberedListData(items.toList()).also {
        it.blockWidth = blockWidth
        it.blockHeight = blockHeight
    }
}

data class TodoItemInstance(var text: String, var isCompleted: Boolean)

data class TodoBlockState(
    val base: BlockData.TodoData,
    val items: SnapshotStateList<TodoItemInstance> = mutableStateListOf(
        *base.items.map { TodoItemInstance(it.text, it.isCompleted) }.toTypedArray()
    )
) : BlockState() {
    override fun toData(): BlockData = BlockData.TodoData(
        items.map { TodoItem(it.text, it.isCompleted) }
    ).also {
        it.blockWidth = blockWidth
        it.blockHeight = blockHeight
    }
}

data class CodeBlockState(
    val base: BlockData.CodeData,
    var language: String = base.language,
    var code: String = base.code
) : BlockState() {
    override fun toData(): BlockData = BlockData.CodeData(language, code).also {
        it.blockWidth = blockWidth
        it.blockHeight = blockHeight
    }
}

data class AttachmentBlockState(
    val base: BlockData.AttachmentData
) : BlockState() {
    override fun toData(): BlockData = base.also {
        it.blockWidth = blockWidth
        it.blockHeight = blockHeight
    }
}

data class MindMapBlockState(
    val base: BlockData.MindMapData,
    var title: String = base.title,
    val nodes: SnapshotStateList<String> = mutableStateListOf(*base.nodes.toTypedArray())
) : BlockState() {
    override fun toData(): BlockData = BlockData.MindMapData(title, nodes.toList()).also {
        it.blockWidth = blockWidth
        it.blockHeight = blockHeight
    }
}

// ================================================================
// JSON 序列化 / 反序列化
// ================================================================

fun BlockData.toJson(): JSONObject {
    val obj = JSONObject()
    obj.put("type", BlockType.from(this))
    when (this) {
        is BlockData.TextData -> {
            obj.put("text", text)
            obj.put("isBold", isBold)
            obj.put("isItalic", isItalic)
        }
        is BlockData.HeadingData -> {
            obj.put("level", level)
            obj.put("text", text)
        }
        is BlockData.BulletListData -> obj.put("items", JSONArray(items))
        is BlockData.NumberedListData -> obj.put("items", JSONArray(items))
        is BlockData.TodoData -> {
            val arr = JSONArray()
            items.forEach {
                val itemObj = JSONObject()
                itemObj.put("text", it.text)
                itemObj.put("completed", it.isCompleted)
                arr.put(itemObj)
            }
            obj.put("items", arr)
        }
        is BlockData.CodeData -> {
            obj.put("language", language)
            obj.put("code", code)
        }
        is BlockData.AttachmentData -> {
            obj.put("name", fileName)
            obj.put("fileType", fileType)
            obj.put("path", encryptedRelativePath)
        }
        is BlockData.MindMapData -> {
            obj.put("title", title)
            obj.put("nodes", JSONArray(nodes))
        }
    }
    // 持久化尺寸
    blockWidth?.let { obj.put("blockWidth", it) } ?: obj.put("blockWidth", JSONObject.NULL)
    blockHeight?.let { obj.put("blockHeight", it) } ?: obj.put("blockHeight", JSONObject.NULL)
    return obj
}

fun parseBlockFromJson(obj: JSONObject): BlockData {
    val data = when (obj.optString("type")) {
        BlockType.TEXT -> BlockData.TextData(
            obj.optString("text", ""),
            obj.optBoolean("isBold"),
            obj.optBoolean("isItalic")
        )
        BlockType.HEADING -> BlockData.HeadingData(
            obj.optInt("level", 1),
            obj.optString("text", "")
        )
        BlockType.BULLET_LIST -> {
            val arr = obj.optJSONArray("items")
            BlockData.BulletListData(
                if (arr != null) List(arr.length()) { arr.getString(it) } else emptyList()
            )
        }
        BlockType.NUMBERED_LIST -> {
            val arr = obj.optJSONArray("items")
            BlockData.NumberedListData(
                if (arr != null) List(arr.length()) { arr.getString(it) } else emptyList()
            )
        }
        BlockType.TODO -> {
            val arr = obj.optJSONArray("items")
            val items = if (arr != null) {
                List(arr.length()) {
                    val itemObj = arr.getJSONObject(it)
                    TodoItem(itemObj.optString("text"), itemObj.optBoolean("completed"))
                }
            } else emptyList()
            BlockData.TodoData(items)
        }
        BlockType.CODE -> BlockData.CodeData(
            obj.optString("language", ""),
            obj.optString("code", "")
        )
        BlockType.ATTACHMENT -> BlockData.AttachmentData(
            obj.optString("name", ""),
            obj.optString("fileType", ""),
            obj.optString("path", "")
        )
        BlockType.MINDMAP -> {
            val nodesArr = obj.optJSONArray("nodes")
            val nodes = if (nodesArr != null) List(nodesArr.length()) {
                nodesArr.getString(it)
            } else emptyList()
            BlockData.MindMapData(obj.optString("title", ""), nodes)
        }
        else -> BlockData.TextData(obj.optString("content", ""))
    }
    // 读取尺寸
    val w = obj.optDouble("blockWidth", Double.NaN)
    val h = obj.optDouble("blockHeight", Double.NaN)
    if (!w.isNaN() && w > 0) data.blockWidth = w.toFloat()
    if (!h.isNaN() && h > 0) data.blockHeight = h.toFloat()
    return data
}

fun blockDataToState(data: BlockData): BlockState {
    val state = when (data) {
        is BlockData.TextData -> TextBlockState(data)
        is BlockData.HeadingData -> HeadingBlockState(data)
        is BlockData.BulletListData -> BulletListBlockState(data)
        is BlockData.NumberedListData -> NumberedListBlockState(data)
        is BlockData.TodoData -> TodoBlockState(data)
        is BlockData.CodeData -> CodeBlockState(data)
        is BlockData.AttachmentData -> AttachmentBlockState(data)
        is BlockData.MindMapData -> MindMapBlockState(data)
    }
    state.blockWidth = data.blockWidth
    state.blockHeight = data.blockHeight
    return state
}
