package com.example.noteapp.ui.screen

import android.graphics.Bitmap
import android.graphics.pdf.PdfRenderer
import android.net.Uri
import android.os.ParcelFileDescriptor
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.GridItemSpan
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.itemsIndexed
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.painter.BitmapPainter
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import coil.compose.rememberAsyncImagePainter
import com.example.noteapp.data.local.Note
import com.example.noteapp.domain.command.*
import com.example.noteapp.ui.component.AttachmentCard
import com.example.noteapp.ui.viewmodel.EditorViewModel
import com.example.noteapp.ui.viewmodel.NoteViewModel
import com.example.noteapp.util.FileEncryptionUtil
import com.example.noteapp.util.ThumbnailCache
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import org.json.JSONArray

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun EditorScreen(
    noteId: Long,
    onBack: () -> Unit,
    onPreview: (String, String) -> Unit,
    viewModel: NoteViewModel = viewModel(),
    editorViewModel: EditorViewModel = viewModel()
) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    val snackbarHostState = remember { SnackbarHostState() }

    val commandManager = remember { CommandManager() }
    val editorState = remember { EditorBlocksState() }

    var title by remember { mutableStateOf("") }
    var savedNoteId by remember { mutableStateOf(0L) }
    var showBlockMenu by remember { mutableStateOf(false) }
    var isGridMode by remember { mutableStateOf(false) }

    // 监听保存结果
    val saveResult by editorViewModel.saveResult.collectAsStateWithLifecycle(
        initialValue = null
    )
    LaunchedEffect(saveResult) {
        saveResult?.let { result ->
            when (result) {
                is EditorViewModel.SaveResult.Success -> {
                    savedNoteId = result.noteId
                    snackbarHostState.showSnackbar("已保存")
                }
                is EditorViewModel.SaveResult.Failure -> {
                    snackbarHostState.showSnackbar("保存失败: ${result.message}")
                }
            }
        }
    }

    // 加载已有笔记
    LaunchedEffect(noteId) {
        if (noteId != 0L) {
            viewModel.getNoteById(noteId)?.let { note ->
                title = note.title
                savedNoteId = note.id
                val arr = JSONArray(note.content)
                for (i in 0 until arr.length()) {
                    val data = parseBlockFromJson(arr.getJSONObject(i))
                    editorState.addBlock(editorState.blockStates.size, blockDataToState(data))
                }
            }
        }
    }

    // 文件选择器（多文件）
    val filePickerLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.GetMultipleContents()
    ) { uris: List<Uri> ->
        uris.forEach { uri ->
            val fileName = getFileName(context, uri) ?: "attachment"
            val mimeType = context.contentResolver.getType(uri) ?: "application/octet-stream"
            val encryptedName = FileEncryptionUtil.encryptAndSave(context, uri, fileName)
            if (encryptedName != null) {
                val idx = editorState.blockStates.size
                commandManager.execute(
                    EditorCommand.InsertBlock(
                        idx,
                        AttachmentBlockState(
                            BlockData.AttachmentData(
                                fileName = fileName,
                                fileType = mimeType,
                                encryptedRelativePath = encryptedName
                            )
                        )
                    ),
                    editorState
                )
            }
        }
    }

    Scaffold(
        snackbarHost = { SnackbarHost(snackbarHostState) },
        topBar = {
            TopAppBar(
                title = { Text(if (savedNoteId == 0L) "新建笔记" else "编辑笔记") },
                navigationIcon = {
                    IconButton(onClick = {
                        scope.launch {
                            val newId = editorViewModel.saveNote(
                                savedNoteId, title, editorState.blockStates.toList()
                            )
                            if (newId > 0) savedNoteId = newId
                            onBack()
                        }
                    }) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, "返回")
                    }
                },
                actions = {
                    IconButton(onClick = { isGridMode = !isGridMode }) {
                        Icon(
                            if (isGridMode) Icons.Default.ViewList else Icons.Default.GridView,
                            if (isGridMode) "列表视图" else "网格视图"
                        )
                    }
                    IconButton(
                        onClick = { commandManager.undo(editorState) },
                        enabled = commandManager.canUndo()
                    ) { Icon(Icons.Default.Undo, "撤销") }
                    IconButton(
                        onClick = { commandManager.redo(editorState) },
                        enabled = commandManager.canRedo()
                    ) { Icon(Icons.Default.Redo, "重做") }
                    IconButton(onClick = {
                        scope.launch {
                            val newId = editorViewModel.saveNote(
                                savedNoteId, title, editorState.blockStates.toList()
                            )
                            if (newId > 0) savedNoteId = newId
                        }
                    }) { Icon(Icons.Default.Save, "保存") }
                }
            )
        }
    ) { padding ->
        if (isGridMode) {
            LazyVerticalGrid(
                columns = GridCells.Adaptive(minSize = 160.dp),
                modifier = Modifier.fillMaxSize().padding(padding).padding(horizontal = 16.dp),
                verticalArrangement = Arrangement.spacedBy(8.dp),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                item(span = { GridItemSpan(maxLineSpan) }) {
                    TitleField(title = title, onTitleChange = { title = it })
                }
                itemsIndexed(
                    editorState.blockStates,
                    key = { index, _ -> editorState.getBlockId(index) }
                ) { index, state ->
                    DraggableBlock(
                        index = index,
                        blockState = state,
                        commandManager = commandManager,
                        editorState = editorState,
                        onPreview = onPreview,
                        onDelete = {
                            commandManager.execute(
                                EditorCommand.DeleteBlock(index, state), editorState
                            )
                        }
                    )
                }
                item(span = { GridItemSpan(maxLineSpan) }) {
                    AddBlockButtons(
                        onAddBlock = { blockState ->
                            val idx = editorState.blockStates.size
                            commandManager.execute(
                                EditorCommand.InsertBlock(idx, blockState), editorState
                            )
                        },
                        onAddAttachment = { filePickerLauncher.launch("*/*") }
                    )
                }
                item(span = { GridItemSpan(maxLineSpan) }) { Spacer(Modifier.height(80.dp)) }
            }
        } else {
            LazyColumn(
                modifier = Modifier.fillMaxSize().padding(padding).padding(horizontal = 16.dp),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                item { TitleField(title = title, onTitleChange = { title = it }) }
                itemsIndexed(
                    editorState.blockStates,
                    key = { index, _ -> editorState.getBlockId(index) }
                ) { index, state ->
                    DraggableBlock(
                        index = index,
                        blockState = state,
                        commandManager = commandManager,
                        editorState = editorState,
                        onPreview = onPreview,
                        onDelete = {
                            commandManager.execute(
                                EditorCommand.DeleteBlock(index, state), editorState
                            )
                        }
                    )
                }
                item {
                    AddBlockButtons(
                        onAddBlock = { blockState ->
                            val idx = editorState.blockStates.size
                            commandManager.execute(
                                EditorCommand.InsertBlock(idx, blockState), editorState
                            )
                        },
                        onAddAttachment = { filePickerLauncher.launch("*/*") }
                    )
                }
                item { Spacer(Modifier.height(80.dp)) }
            }
        }
    }
}

// ================================================================
// 可拖拽的块容器
// ================================================================
@Composable
private fun DraggableBlock(
    index: Int,
    blockState: BlockState,
    commandManager: CommandManager,
    editorState: EditorBlocksState,
    onPreview: (String, String) -> Unit,
    onDelete: () -> Unit
) {
    var isDragging by remember { mutableStateOf(false) }
    var dragOffset by remember { mutableStateOf(0f) }

    Box(
        modifier = Modifier
            .then(
                if (blockState.blockWidth != null) Modifier.width(blockState.blockWidth!!.dp)
                else Modifier.fillMaxWidth()
            )
            .then(
                if (blockState.blockHeight != null) Modifier.height(blockState.blockHeight!!.dp)
                else Modifier.wrapContentHeight()
            )
            .offset(y = dragOffset.dp)
            .background(
                if (isDragging) MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.3f)
                else MaterialTheme.colorScheme.surface,
                RoundedCornerShape(8.dp)
            )
            .border(
                1.dp,
                if (isDragging) MaterialTheme.colorScheme.primary.copy(alpha = 0.5f)
                else MaterialTheme.colorScheme.outline.copy(alpha = 0.1f),
                RoundedCornerShape(8.dp)
            )
            .pointerInput(Unit) {
                detectDragGestures(
                    onDragStart = { isDragging = true },
                    onDragEnd = {
                        isDragging = false
                        // 根据拖拽距离判断是否需要移动
                        val targetIndex = calculateDropIndex(
                            dragOffset, index, editorState.blockStates.size
                        )
                        if (targetIndex != index && targetIndex >= 0) {
                            commandManager.execute(
                                EditorCommand.MoveBlock(index, targetIndex), editorState
                            )
                        }
                        dragOffset = 0f
                    },
                    onDragCancel = {
                        isDragging = false
                        dragOffset = 0f
                    },
                    onDrag = { change, dragAmount ->
                        change.consume()
                        dragOffset += dragAmount.y
                    }
                )
            }
            .padding(4.dp)
    ) {
        BlockView(
            index = index,
            blockState = blockState,
            commandManager = commandManager,
            editorState = editorState,
            onPreview = onPreview,
            onDelete = onDelete
        )
    }
}

private fun calculateDropIndex(dragOffset: Float, currentIndex: Int, totalSize: Int): Int {
    val threshold = 40f // 拖拽超过 40dp 算移动到相邻位置
    return when {
        dragOffset < -threshold && currentIndex > 0 -> currentIndex - 1
        dragOffset > threshold && currentIndex < totalSize - 1 -> currentIndex + 1
        else -> currentIndex
    }
}

// ================================================================
// 标题输入框
// ================================================================
@Composable
private fun TitleField(title: String, onTitleChange: (String) -> Unit) {
    OutlinedTextField(
        value = title,
        onValueChange = onTitleChange,
        placeholder = { Text("标题", style = MaterialTheme.typography.headlineSmall) },
        modifier = Modifier.fillMaxWidth(),
        textStyle = MaterialTheme.typography.headlineSmall,
        singleLine = true,
        colors = OutlinedTextFieldDefaults.colors(
            focusedBorderColor = MaterialTheme.colorScheme.outline.copy(alpha = 0.3f),
            unfocusedBorderColor = MaterialTheme.colorScheme.outline.copy(alpha = 0.1f)
        )
    )
    Spacer(Modifier.height(8.dp))
}

// ================================================================
// 单个块的视图
// ================================================================
@Composable
fun BlockView(
    index: Int,
    blockState: BlockState,
    commandManager: CommandManager,
    editorState: EditorBlocksState,
    onPreview: (String, String) -> Unit,
    onDelete: () -> Unit
) {
    // 使用 derivedStateOf 替代 hack 写法
    val version = remember { derivedStateOf { editorState.version.intValue } }
    val _ = version.value

    var showActions by remember { mutableStateOf(false) }
    var showContextMenu by remember { mutableStateOf(false) }

    Column(modifier = Modifier.padding(vertical = 4.dp)) {
        // 块类型标签行 + 拖拽手柄
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .clickable { showActions = !showActions },
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            // 左侧色条
            Box(
                modifier = Modifier
                    .width(3.dp)
                    .height(20.dp)
                    .background(
                        when (blockState) {
                            is TextBlockState -> MaterialTheme.colorScheme.outline.copy(alpha = 0.3f)
                            is HeadingBlockState -> MaterialTheme.colorScheme.primary
                            is CodeBlockState -> MaterialTheme.colorScheme.tertiary
                            is AttachmentBlockState -> MaterialTheme.colorScheme.secondary
                            else -> MaterialTheme.colorScheme.primary.copy(alpha = 0.5f)
                        },
                        RoundedCornerShape(2.dp)
                    )
            )

            // 拖拽手柄
            Icon(
                Icons.Default.DragHandle,
                contentDescription = "拖拽排序",
                modifier = Modifier.size(16.dp),
                tint = MaterialTheme.colorScheme.outline.copy(alpha = 0.5f)
            )

            if (showActions) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    when (blockState) {
                        is TextBlockState -> {
                            IconButton(
                                onClick = {
                                    commandManager.execute(
                                        EditorCommand.ToggleFormat(
                                            index, FormatType.BOLD,
                                            blockState.isBold, !blockState.isBold
                                        ), editorState
                                    )
                                },
                                modifier = Modifier.size(28.dp)
                            ) {
                                Icon(
                                    Icons.Default.FormatBold, "加粗",
                                    Modifier.size(16.dp),
                                    tint = if (blockState.isBold) MaterialTheme.colorScheme.primary
                                    else MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            }
                            IconButton(
                                onClick = {
                                    commandManager.execute(
                                        EditorCommand.ToggleFormat(
                                            index, FormatType.ITALIC,
                                            blockState.isItalic, !blockState.isItalic
                                        ), editorState
                                    )
                                },
                                modifier = Modifier.size(28.dp)
                            ) {
                                Icon(
                                    Icons.Default.FormatItalic, "斜体",
                                    Modifier.size(16.dp),
                                    tint = if (blockState.isItalic) MaterialTheme.colorScheme.primary
                                    else MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            }
                        }
                        is HeadingBlockState -> {
                            IconButton(
                                onClick = {
                                    val newLevel = if (blockState.level > 1) blockState.level - 1 else 6
                                    commandManager.execute(
                                        EditorCommand.UpdateHeadingLevel(
                                            index, blockState.level, newLevel
                                        ), editorState
                                    )
                                },
                                modifier = Modifier.size(28.dp)
                            ) { Icon(Icons.Default.Remove, "降级", Modifier.size(16.dp)) }
                            IconButton(
                                onClick = {
                                    val newLevel = if (blockState.level < 6) blockState.level + 1 else 1
                                    commandManager.execute(
                                        EditorCommand.UpdateHeadingLevel(
                                            index, blockState.level, newLevel
                                        ), editorState
                                    )
                                },
                                modifier = Modifier.size(28.dp)
                            ) { Icon(Icons.Default.Add, "升级", Modifier.size(16.dp)) }
                        }
                        else -> {}
                    }
                    IconButton(onClick = { showContextMenu = true }, modifier = Modifier.size(28.dp)) {
                        Icon(Icons.Default.MoreVert, "更多", Modifier.size(16.dp))
                    }
                    IconButton(onClick = onDelete, modifier = Modifier.size(28.dp)) {
                        Icon(Icons.Default.Delete, "删除", Modifier.size(16.dp),
                            tint = MaterialTheme.colorScheme.error)
                    }
                }
            }
        }

        // 长按上下文菜单
        DropdownMenu(
            expanded = showContextMenu,
            onDismissRequest = { showContextMenu = false }
        ) {
            DropdownMenuItem(
                text = { Text("复制块") },
                onClick = {
                    showContextMenu = false
                    // TODO: 实现复制块
                },
                leadingIcon = { Icon(Icons.Default.ContentCopy, null) }
            )
            DropdownMenuItem(
                text = { Text("删除块", color = MaterialTheme.colorScheme.error) },
                onClick = {
                    showContextMenu = false
                    onDelete()
                },
                leadingIcon = { Icon(Icons.Default.Delete, null, tint = MaterialTheme.colorScheme.error) }
            )
        }

        // 块内容
        Box(modifier = Modifier.fillMaxWidth()) {
            when (blockState) {
                is TextBlockState -> TextBlockEditor(blockState, index, commandManager, editorState)
                is HeadingBlockState -> HeadingEditor(blockState, index, commandManager, editorState)
                is BulletListBlockState -> BulletListEditor(blockState, index, commandManager, editorState)
                is NumberedListBlockState -> NumberedListEditor(blockState, index, commandManager, editorState)
                is TodoBlockState -> TodoEditor(blockState, index, commandManager, editorState)
                is CodeBlockState -> CodeEditor(blockState, index, commandManager, editorState)
                is AttachmentBlockState -> AttachmentBlockPreview(
                    blockState = blockState,
                    onPreview = onPreview,
                    onDelete = onDelete
                )
                is MindMapBlockState -> MindMapEditor(blockState, index, commandManager, editorState)
            }
        }

        // 拖拽调整大小手柄
        if (showActions) {
            Box(
                modifier = Modifier
                    .align(Alignment.End)
                    .size(16.dp)
                    .pointerInput(Unit) {
                        detectDragGestures { change, dragAmount ->
                            change.consume()
                            val currentW = blockState.blockWidth ?: 300f
                            val currentH = blockState.blockHeight ?: 100f
                            blockState.blockWidth = (currentW + dragAmount.x).coerceAtLeast(80f)
                            blockState.blockHeight = (currentH + dragAmount.y).coerceAtLeast(40f)
                            editorState.version.intValue++
                        }
                    },
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    Icons.Default.DragHandle,
                    contentDescription = "调整大小",
                    modifier = Modifier.size(14.dp),
                    tint = MaterialTheme.colorScheme.outline.copy(alpha = 0.5f)
                )
            }
        }
    }
}

// ================================================================
// 附件块内嵌预览（异步加载 + 缓存）
// ================================================================
@Composable
fun AttachmentBlockPreview(
    blockState: AttachmentBlockState,
    onPreview: (String, String) -> Unit,
    onDelete: () -> Unit
) {
    val context = LocalContext.current
    val fileName = blockState.base.fileName
    val fileType = blockState.base.fileType
    val encryptedPath = blockState.base.encryptedRelativePath

    var decryptedPath by remember { mutableStateOf<String?>(null) }
    var isLoading by remember { mutableStateOf(true) }
    var loadError by remember { mutableStateOf<String?>(null) }

    // 异步解密（IO 线程）
    LaunchedEffect(encryptedPath) {
        isLoading = true
        loadError = null
        val result = withContext(Dispatchers.IO) {
            try {
                FileEncryptionUtil.decryptToTemp(context, encryptedPath)
            } catch (e: Exception) {
                null
            }
        }
        if (result != null) {
            decryptedPath = result
        } else {
            loadError = "解密失败"
        }
        isLoading = false
    }

    Card(
        modifier = Modifier
            .fillMaxWidth()
            .clickable { onPreview(encryptedPath, fileType) },
        elevation = CardDefaults.cardElevation(defaultElevation = 1.dp)
    ) {
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .heightIn(min = 80.dp, max = 200.dp)
                .padding(8.dp),
            contentAlignment = Alignment.Center
        ) {
            when {
                isLoading -> {
                    CircularProgressIndicator(modifier = Modifier.size(24.dp), strokeWidth = 2.dp)
                }
                loadError != null -> {
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Icon(
                            Icons.Default.ErrorOutline,
                            contentDescription = null,
                            tint = MaterialTheme.colorScheme.error,
                            modifier = Modifier.size(32.dp)
                        )
                        Spacer(Modifier.height(4.dp))
                        Text("解密失败", style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.error)
                    }
                }
                decryptedPath != null -> {
                    AttachmentInlineContent(
                        decryptedPath = decryptedPath!!,
                        fileName = fileName,
                        fileType = fileType
                    )
                }
            }
        }

        // 底部文件名行
        Row(
            modifier = Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 4.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Icon(
                imageVector = when {
                    fileType.startsWith("image/") -> Icons.Default.Image
                    fileType == "application/pdf" -> Icons.Default.PictureAsPdf
                    fileType.startsWith("audio/") -> Icons.Default.Audiotrack
                    fileType.startsWith("video/") -> Icons.Default.Videocam
                    fileType.startsWith("text/") -> Icons.Default.TextSnippet
                    else -> Icons.Default.InsertDriveFile
                },
                contentDescription = null,
                tint = MaterialTheme.colorScheme.primary,
                modifier = Modifier.size(18.dp)
            )
            Spacer(modifier = Modifier.width(6.dp))
            Text(
                text = fileName,
                style = MaterialTheme.typography.bodySmall,
                maxLines = 1,
                overflow = androidx.compose.ui.text.style.TextOverflow.Ellipsis,
                modifier = Modifier.weight(1f),
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
            IconButton(onClick = onDelete, modifier = Modifier.size(24.dp)) {
                Icon(Icons.Default.Close, "删除附件", Modifier.size(14.dp),
                    tint = MaterialTheme.colorScheme.error)
            }
        }
    }
}

// ================================================================
// 附件内联内容分发（异步缩略图 + 音视频内嵌播放）
// ================================================================
@Composable
fun AttachmentInlineContent(
    decryptedPath: String,
    fileName: String,
    fileType: String
) {
    when {
        // 图片：异步加载缩略图（Coil 内部异步 + 缓存）
        fileType.startsWith("image/") -> {
            Image(
                painter = rememberAsyncImagePainter(
                    model = java.io.File(decryptedPath),
                    placeholder = null,
                    error = null
                ),
                contentDescription = fileName,
                modifier = Modifier.fillMaxSize(),
                contentScale = ContentScale.Crop
            )
        }

        // PDF：异步渲染首页缩略图
        fileType == "application/pdf" -> {
            PdfThumbnailAsync(decryptedPath)
        }

        // 文本：异步读取前 500 字符
        fileType.startsWith("text/") ||
        fileType in listOf("application/json", "application/xml",
            "application/javascript", "application/x-yaml") -> {
            TextSnippetAsync(decryptedPath)
        }

        // 音频：内嵌播放器
        fileType.startsWith("audio/") -> {
            AudioPlayer(
                filePath = decryptedPath,
                fileName = fileName,
                modifier = Modifier.fillMaxWidth()
            )
        }

        // 视频：内嵌播放器
        fileType.startsWith("video/") -> {
            VideoPlayer(
                filePath = decryptedPath,
                modifier = Modifier.fillMaxWidth()
            )
        }

        // 未知类型
        else -> {
            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                Icon(
                    Icons.Default.InsertDriveFile,
                    contentDescription = null,
                    modifier = Modifier.size(40.dp),
                    tint = MaterialTheme.colorScheme.outline
                )
                Spacer(Modifier.height(4.dp))
                Text("点击预览", style = MaterialTheme.typography.bodySmall)
            }
        }
    }
}

// ================================================================
// 异步 PDF 缩略图（IO 线程渲染 + 缓存）
// ================================================================
@Composable
fun PdfThumbnailAsync(path: String) {
    var bitmap by remember(path) { mutableStateOf<Bitmap?>(null) }
    var error by remember(path) { mutableStateOf<String?>(null) }

    LaunchedEffect(path) {
        val cached = ThumbnailCache.get("pdf_$path")
        if (cached != null) {
            bitmap = cached
            return@LaunchedEffect
        }

        val result = withContext(Dispatchers.IO) {
            ThumbnailCache.createPdfThumbnail(java.io.File(path))
        }

        if (result != null) {
            ThumbnailCache.put("pdf_$path", result)
            bitmap = result
        } else {
            error = "PDF 预览失败"
        }
    }

    when {
        bitmap != null -> {
            Image(
                painter = BitmapPainter(bitmap!!.asImageBitmap()),
                contentDescription = "PDF 缩略图",
                modifier = Modifier.fillMaxSize(),
                contentScale = ContentScale.Fit
            )
        }
        error != null -> {
            Text(error!!, style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.error)
        }
        else -> {
            CircularProgressIndicator(modifier = Modifier.size(20.dp), strokeWidth = 2.dp)
        }
    }
}

// ================================================================
// 异步文本片段
// ================================================================
@Composable
fun TextSnippetAsync(path: String) {
    var content by remember(path) { mutableStateOf<String?>(null) }
    var error by remember(path) { mutableStateOf<String?>(null) }

    LaunchedEffect(path) {
        try {
            content = withContext(Dispatchers.IO) {
                java.io.File(path).readText().take(500)
            }
        } catch (e: Exception) {
            error = "读取失败"
        }
    }

    when {
        content != null -> {
            Text(
                text = content!!,
                style = TextStyle(
                    fontSize = 11.sp,
                    fontFamily = FontFamily.Monospace,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                ),
                maxLines = 6,
                overflow = androidx.compose.ui.text.style.TextOverflow.Ellipsis
            )
        }
        error != null -> {
            Text(error!!, style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.error)
        }
        else -> {
            CircularProgressIndicator(modifier = Modifier.size(20.dp), strokeWidth = 2.dp)
        }
    }
}

// ================================================================
// 各类型编辑器
// ================================================================
@Composable
fun TextBlockEditor(
    state: TextBlockState, index: Int,
    commandManager: CommandManager, editorState: EditorBlocksState
) {
    val version = remember { derivedStateOf { editorState.version.intValue } }
    val _ = version.value

    val textStyle = TextStyle(
        fontWeight = if (state.isBold) FontWeight.Bold else FontWeight.Normal,
        fontStyle = if (state.isItalic) FontStyle.Italic else FontStyle.Normal,
        fontSize = 16.sp
    )
    androidx.compose.foundation.text.BasicTextField(
        value = state.text,
        onValueChange = { newText ->
            commandManager.execute(
                EditorCommand.UpdateText(index, state.text, newText), editorState
            )
        },
        modifier = Modifier.fillMaxWidth().padding(vertical = 6.dp),
        textStyle = textStyle,
        decorationBox = { innerTextField ->
            Box {
                if (state.text.isEmpty()) {
                    Text("输入文本...", style = textStyle.copy(color = MaterialTheme.colorScheme.outline))
                }
                innerTextField()
            }
        }
    )
}

@Composable
fun HeadingEditor(
    state: HeadingBlockState, index: Int,
    commandManager: CommandManager, editorState: EditorBlocksState
) {
    val version = remember { derivedStateOf { editorState.version.intValue } }
    val _ = version.value

    val fontSize = when (state.level) {
        1 -> 28.sp; 2 -> 24.sp; 3 -> 20.sp
        4 -> 18.sp; 5 -> 16.sp; else -> 14.sp
    }
    val textStyle = TextStyle(fontSize = fontSize, fontWeight = FontWeight.Bold)
    androidx.compose.foundation.text.BasicTextField(
        value = state.text,
        onValueChange = { newText ->
            commandManager.execute(
                EditorCommand.UpdateText(index, state.text, newText), editorState
            )
        },
        modifier = Modifier.fillMaxWidth().padding(vertical = 6.dp),
        textStyle = textStyle,
        decorationBox = { innerTextField ->
            Box {
                if (state.text.isEmpty()) {
                    Text("标题...", style = textStyle.copy(color = MaterialTheme.colorScheme.outline))
                }
                innerTextField()
            }
        }
    )
}

@Composable
fun BulletListEditor(
    state: BulletListBlockState, index: Int,
    commandManager: CommandManager, editorState: EditorBlocksState
) {
    val version = remember { derivedStateOf { editorState.version.intValue } }
    val _ = version.value

    Column {
        state.items.forEachIndexed { itemIndex, item ->
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text("•", modifier = Modifier.padding(end = 8.dp))
                OutlinedTextField(
                    value = item,
                    onValueChange = { newValue ->
                        commandManager.execute(
                            EditorCommand.UpdateListItem(index, itemIndex, item, newValue), editorState
                        )
                    },
                    modifier = Modifier.weight(1f),
                    singleLine = true,
                    textStyle = TextStyle(fontSize = 14.sp),
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = MaterialTheme.colorScheme.outline.copy(alpha = 0.2f),
                        unfocusedBorderColor = MaterialTheme.colorScheme.outline.copy(alpha = 0.1f)
                    )
                )
            }
        }
        TextButton(onClick = { state.items.add("") }) { Text("+ 添加项目") }
    }
}

@Composable
fun NumberedListEditor(
    state: NumberedListBlockState, index: Int,
    commandManager: CommandManager, editorState: EditorBlocksState
) {
    val version = remember { derivedStateOf { editorState.version.intValue } }
    val _ = version.value

    Column {
        state.items.forEachIndexed { itemIndex, item ->
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text("${itemIndex + 1}.", modifier = Modifier.padding(end = 8.dp))
                OutlinedTextField(
                    value = item,
                    onValueChange = { newValue ->
                        commandManager.execute(
                            EditorCommand.UpdateListItem(index, itemIndex, item, newValue), editorState
                        )
                    },
                    modifier = Modifier.weight(1f),
                    singleLine = true,
                    textStyle = TextStyle(fontSize = 14.sp),
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = MaterialTheme.colorScheme.outline.copy(alpha = 0.2f),
                        unfocusedBorderColor = MaterialTheme.colorScheme.outline.copy(alpha = 0.1f)
                    )
                )
            }
        }
        TextButton(onClick = { state.items.add("") }) { Text("+ 添加项目") }
    }
}

@Composable
fun TodoEditor(
    state: TodoBlockState, index: Int,
    commandManager: CommandManager, editorState: EditorBlocksState
) {
    val version = remember { derivedStateOf { editorState.version.intValue } }
    val _ = version.value

    Column {
        state.items.forEachIndexed { itemIndex, item ->
            Row(verticalAlignment = Alignment.CenterVertically) {
                Checkbox(
                    checked = item.isCompleted,
                    onCheckedChange = { newChecked ->
                        commandManager.execute(
                            EditorCommand.ToggleTodoItem(
                                index, itemIndex, item.isCompleted, newChecked
                            ), editorState
                        )
                    }
                )
                OutlinedTextField(
                    value = item.text,
                    onValueChange = { newText ->
                        commandManager.execute(
                            EditorCommand.UpdateListItem(index, itemIndex, item.text, newText), editorState
                        )
                    },
                    modifier = Modifier.weight(1f),
                    singleLine = true,
                    textStyle = TextStyle(fontSize = 14.sp),
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = MaterialTheme.colorScheme.outline.copy(alpha = 0.2f),
                        unfocusedBorderColor = MaterialTheme.colorScheme.outline.copy(alpha = 0.1f)
                    )
                )
            }
        }
        TextButton(onClick = { state.items.add(TodoItemInstance("", false)) }) {
            Text("+ 添加待办")
        }
    }
}

@Composable
fun CodeEditor(
    state: CodeBlockState, index: Int,
    commandManager: CommandManager, editorState: EditorBlocksState
) {
    val version = remember { derivedStateOf { editorState.version.intValue } }
    val _ = version.value

    Column {
        OutlinedTextField(
            value = state.language,
            onValueChange = { state.language = it },
            modifier = Modifier.fillMaxWidth(),
            singleLine = true,
            placeholder = { Text("语言 (如 kotlin, python)") },
            textStyle = TextStyle(fontSize = 12.sp, fontFamily = FontFamily.Monospace),
            colors = OutlinedTextFieldDefaults.colors(
                focusedBorderColor = MaterialTheme.colorScheme.outline.copy(alpha = 0.2f),
                unfocusedBorderColor = MaterialTheme.colorScheme.outline.copy(alpha = 0.1f)
            )
        )
        Spacer(Modifier.height(4.dp))
        OutlinedTextField(
            value = state.code,
            onValueChange = { newCode ->
                commandManager.execute(
                    EditorCommand.UpdateText(index, state.code, newCode), editorState
                )
            },
            modifier = Modifier.fillMaxWidth().heightIn(min = 100.dp),
            textStyle = TextStyle(fontSize = 13.sp, fontFamily = FontFamily.Monospace),
            placeholder = { Text("输入代码...") },
            colors = OutlinedTextFieldDefaults.colors(
                focusedBorderColor = MaterialTheme.colorScheme.outline.copy(alpha = 0.2f),
                unfocusedBorderColor = MaterialTheme.colorScheme.outline.copy(alpha = 0.1f)
            )
        )
    }
}

@Composable
fun MindMapEditor(
    state: MindMapBlockState, index: Int,
    commandManager: CommandManager, editorState: EditorBlocksState
) {
    val version = remember { derivedStateOf { editorState.version.intValue } }
    val _ = version.value

    Column {
        OutlinedTextField(
            value = state.title,
            onValueChange = { state.title = it },
            modifier = Modifier.fillMaxWidth(),
            singleLine = true,
            placeholder = { Text("思维导图标题") },
            textStyle = TextStyle(fontSize = 14.sp, fontWeight = FontWeight.Bold),
            colors = OutlinedTextFieldDefaults.colors(
                focusedBorderColor = MaterialTheme.colorScheme.outline.copy(alpha = 0.2f),
                unfocusedBorderColor = MaterialTheme.colorScheme.outline.copy(alpha = 0.1f)
            )
        )
        state.nodes.forEachIndexed { nodeIndex, node ->
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text("└", modifier = Modifier.padding(end = 8.dp))
                OutlinedTextField(
                    value = node,
                    onValueChange = {
                        state.nodes[nodeIndex] = it
                        editorState.version.intValue++
                    },
                    modifier = Modifier.weight(1f),
                    singleLine = true,
                    textStyle = TextStyle(fontSize = 13.sp),
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = MaterialTheme.colorScheme.outline.copy(alpha = 0.2f),
                        unfocusedBorderColor = MaterialTheme.colorScheme.outline.copy(alpha = 0.1f)
                    )
                )
            }
        }
        TextButton(onClick = { state.nodes.add("") }) { Text("+ 添加节点") }
    }
}

// ================================================================
// 添加块按钮
// ================================================================
@Composable
fun AddBlockButtons(
    onAddBlock: (BlockState) -> Unit,
    onAddAttachment: () -> Unit
) {
    var expanded by remember { mutableStateOf(false) }
    Box(modifier = Modifier.fillMaxWidth().padding(vertical = 8.dp)) {
        OutlinedButton(
            onClick = { expanded = true },
            modifier = Modifier.fillMaxWidth()
        ) {
            Icon(Icons.Default.Add, null, Modifier.size(18.dp))
            Spacer(Modifier.width(4.dp))
            Text("添加块")
        }
        DropdownMenu(expanded = expanded, onDismissRequest = { expanded = false }) {
            DropdownMenuItem(text = { Text("文本") }, onClick = {
                onAddBlock(TextBlockState(BlockData.TextData(""))); expanded = false
            })
            DropdownMenuItem(text = { Text("标题") }, onClick = {
                onAddBlock(HeadingBlockState(BlockData.HeadingData(1, ""))); expanded = false
            })
            DropdownMenuItem(text = { Text("无序列表") }, onClick = {
                onAddBlock(BulletListBlockState(BlockData.BulletListData(listOf("")))); expanded = false
            })
            DropdownMenuItem(text = { Text("有序列表") }, onClick = {
                onAddBlock(NumberedListBlockState(BlockData.NumberedListData(listOf("")))); expanded = false
            })
            DropdownMenuItem(text = { Text("待办") }, onClick = {
                onAddBlock(TodoBlockState(BlockData.TodoData(listOf(TodoItem("", false))))); expanded = false
            })
            DropdownMenuItem(text = { Text("代码") }, onClick = {
                onAddBlock(CodeBlockState(BlockData.CodeData("", ""))); expanded = false
            })
            DropdownMenuItem(text = { Text("思维导图") }, onClick = {
                onAddBlock(MindMapBlockState(BlockData.MindMapData("", emptyList()))); expanded = false
            })
            DropdownMenuItem(text = { Text("附件") }, onClick = {
                onAddAttachment(); expanded = false
            })
        }
    }
}

// ================================================================
// 工具函数
// ================================================================
private fun getFileName(context: android.content.Context, uri: Uri): String? {
    var name: String? = null
    context.contentResolver.query(uri, null, null, null, null)?.use { cursor ->
        val nameIndex = cursor.getColumnIndex(android.provider.OpenableColumns.DISPLAY_NAME)
        if (cursor.moveToFirst() && nameIndex >= 0) {
            name = cursor.getString(nameIndex)
        }
    }
    return name ?: uri.lastPathSegment
}
