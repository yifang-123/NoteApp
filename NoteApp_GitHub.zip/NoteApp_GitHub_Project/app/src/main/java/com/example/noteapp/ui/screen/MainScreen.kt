package com.example.noteapp.ui.screen

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.lifecycle.viewmodel.compose.viewModel
import com.example.noteapp.ui.component.NoteCard
import com.example.noteapp.ui.viewmodel.NoteViewModel
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.launch

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun MainScreen(
    viewModel: NoteViewModel = viewModel(),
    onNoteClick: (Long) -> Unit,
    onAddNote: () -> Unit,
    onTrashClick: () -> Unit
) {
    val allNotes by viewModel.allNotes.collectAsState()
    val allTags by viewModel.allTags.collectAsState()
    val selectedIds by viewModel.selectedIds.collectAsState()

    val drawerState = rememberDrawerState(initialValue = DrawerValue.Closed)
    val scope = rememberCoroutineScope()

    var searchQuery by remember { mutableStateOf("") }
    var selectedTagId by remember { mutableStateOf<Long?>(null) }
    var showSearchDialog by remember { mutableStateOf(false) }
    var selectionMode by remember { mutableStateOf(false) }

    // Filter by tag
    val taggedSet by produceState<Set<Long>?>(null, selectedTagId) {
        value = if (selectedTagId != null) {
            viewModel.getNotesByTag(selectedTagId!!)
                .first()
                .map { it.id }
                .toSet()
        } else null
    }

    val filteredNotes = remember(allNotes, searchQuery, taggedSet) {
        val tagSet = taggedSet
        allNotes.filter { note ->
            val matchesSearch = searchQuery.isBlank() ||
                note.title.contains(searchQuery, ignoreCase = true) ||
                note.previewText.contains(searchQuery, ignoreCase = true)
            val matchesTag = tagSet == null || note.id in tagSet
            matchesSearch && matchesTag
        }
    }

    if (showSearchDialog) {
        AlertDialog(
            onDismissRequest = { showSearchDialog = false },
            title = { Text("搜索笔记") },
            text = {
                OutlinedTextField(
                    value = searchQuery,
                    onValueChange = { searchQuery = it },
                    label = { Text("关键词") },
                    singleLine = true
                )
            },
            confirmButton = {
                TextButton(onClick = { showSearchDialog = false }) { Text("确定") }
            },
            dismissButton = {
                TextButton(onClick = {
                    searchQuery = ""
                    showSearchDialog = false
                }) { Text("清除") }
            }
        )
    }

    ModalNavigationDrawer(
        drawerState = drawerState,
        drawerContent = {
            ModalDrawerSheet {
                Text(
                    "我的笔记",
                    modifier = Modifier.padding(16.dp),
                    style = MaterialTheme.typography.titleLarge
                )
                Divider()
                NavigationDrawerItem(
                    icon = { Icon(Icons.Default.Notes, null) },
                    label = { Text("全部笔记") },
                    selected = selectedTagId == null,
                    onClick = {
                        selectedTagId = null
                        scope.launch { drawerState.close() }
                    }
                )
                Text(
                    "标签",
                    modifier = Modifier.padding(16.dp, 8.dp),
                    style = MaterialTheme.typography.labelLarge
                )
                allTags.forEach { tag ->
                    NavigationDrawerItem(
                        icon = { Icon(Icons.Default.Tag, null) },
                        label = { Text(tag.name) },
                        selected = selectedTagId == tag.id,
                        onClick = {
                            selectedTagId = tag.id
                            scope.launch { drawerState.close() }
                        }
                    )
                }
                Spacer(Modifier.weight(1f))
                Divider()
                NavigationDrawerItem(
                    icon = { Icon(Icons.Default.DeleteOutline, null) },
                    label = { Text("回收站") },
                    selected = false,
                    onClick = {
                        onTrashClick()
                        scope.launch { drawerState.close() }
                    }
                )
            }
        }
    ) {
        Scaffold(
            topBar = {
                if (selectionMode) {
                    CenterAlignedTopAppBar(
                        title = { Text("已选择 ${selectedIds.size} 项") },
                        navigationIcon = {
                            IconButton(onClick = {
                                selectionMode = false
                                viewModel.clearSelection()
                            }) { Icon(Icons.Default.Close, "取消") }
                        },
                        actions = {
                            IconButton(onClick = {
                                viewModel.deleteSelected()
                                selectionMode = false
                            }) { Icon(Icons.Default.Delete, "删除") }
                        }
                    )
                } else {
                    CenterAlignedTopAppBar(
                        title = {
                            Text(
                                if (selectedTagId == null) "笔记"
                                else allTags.find { it.id == selectedTagId }?.name ?: "笔记"
                            )
                        },
                        navigationIcon = {
                            IconButton(onClick = { scope.launch { drawerState.open() } }) {
                                Icon(Icons.Default.Menu, "菜单")
                            }
                        },
                        actions = {
                            IconButton(onClick = { showSearchDialog = true }) {
                                Icon(Icons.Default.Search, "搜索")
                            }
                            IconButton(onClick = { selectionMode = true }) {
                                Icon(Icons.Default.CheckCircleOutline, "选择")
                            }
                        }
                    )
                }
            },
            floatingActionButton = {
                if (!selectionMode) {
                    FloatingActionButton(onClick = onAddNote) {
                        Icon(Icons.Default.Add, "新建")
                    }
                }
            }
        ) { padding ->
            if (filteredNotes.isEmpty()) {
                Box(
                    modifier = Modifier.fillMaxSize().padding(padding),
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        if (searchQuery.isNotBlank() || selectedTagId != null) "没有找到匹配的笔记"
                        else "写下你的第一个想法",
                        color = MaterialTheme.colorScheme.outline
                    )
                }
            } else {
                LazyVerticalGrid(
                    columns = GridCells.Adaptive(minSize = 160.dp),
                    contentPadding = PaddingValues(16.dp),
                    verticalArrangement = Arrangement.spacedBy(16.dp),
                    horizontalArrangement = Arrangement.spacedBy(16.dp),
                    modifier = Modifier.padding(padding)
                ) {
                    items(filteredNotes, key = { it.id }) { note ->
                        val isSelected = selectedIds.contains(note.id)
                        NoteCard(
                            note = note,
                            onClick = {
                                if (selectionMode) viewModel.toggleSelection(note.id)
                                else onNoteClick(note.id)
                            },
                            onLongClick = {
                                if (!selectionMode) {
                                    selectionMode = true
                                    viewModel.toggleSelection(note.id)
                                }
                            },
                            isSelected = isSelected
                        )
                    }
                }
            }
        }
    }
}
