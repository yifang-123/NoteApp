package com.example.noteapp.ui.screen

import android.graphics.Bitmap
import android.graphics.pdf.PdfRenderer
import android.os.ParcelFileDescriptor
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.pager.HorizontalPager
import androidx.compose.foundation.pager.rememberPagerState
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.painter.BitmapPainter
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import coil.compose.AsyncImage
import java.io.File

/**
 * PDF 多页浏览组件
 *
 * 🔧 安全设计（修复原版内存泄漏和渲染崩溃）：
 * - 使用 DisposableEffect 管理 PdfRenderer 生命周期
 * - 每页独立打开/关闭 Page 对象
 * - beyondViewportPageCount = 0（不预加载相邻页）
 * - 所有资源在 finally 中关闭
 * - 渲染在 LaunchedEffect 中异步执行
 */
@OptIn(ExperimentalFoundationApi::class)
@Composable
fun PdfPager(
    pdfPath: String,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    var renderer by remember { mutableStateOf<PdfRenderer?>(null) }
    var totalPages by remember { mutableStateOf(0) }
    var loadError by remember { mutableStateOf<String?>(null) }

    // 创建和销毁 PdfRenderer
    DisposableEffect(pdfPath) {
        var fd: ParcelFileDescriptor? = null
        try {
            val file = File(pdfPath)
            if (!file.exists()) {
                loadError = "文件不存在: $pdfPath"
            } else {
                fd = ParcelFileDescriptor.open(file, ParcelFileDescriptor.MODE_READ_ONLY)
                renderer = PdfRenderer(fd)
                totalPages = renderer!!.pageCount
            }
        } catch (e: Exception) {
            loadError = "PDF 打开失败: ${e.message}"
            fd?.close()
        }

        onDispose {
            renderer?.close()
            renderer = null
            // 注意：fd 在 renderer 内部持有，renderer.close() 会关闭它
        }
    }

    when {
        loadError != null -> {
            Box(modifier = modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                Text(loadError!!, color = androidx.compose.ui.graphics.Color.Red)
            }
        }
        renderer == null -> {
            Box(modifier = modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                androidx.compose.material3.CircularProgressIndicator()
            }
        }
        else -> {
            val pagerState = rememberPagerState(pageCount = { totalPages })

            Column(modifier = modifier.fillMaxSize()) {
                // 页码指示
                Row(
                    modifier = Modifier.fillMaxWidth().padding(8.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "第 ${pagerState.currentPage + 1} / $totalPages 页",
                        style = androidx.compose.material3.MaterialTheme.typography.bodySmall,
                        color = androidx.compose.material3.MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }

                HorizontalPager(
                    state = pagerState,
                    beyondViewportPageCount = 0, // 不预加载，避免内存压力
                    modifier = Modifier.fillMaxSize()
                ) { pageIndex ->
                    PdfPage(
                        renderer = renderer!!,
                        pageIndex = pageIndex,
                        modifier = Modifier.fillMaxSize()
                    )
                }
            }
        }
    }
}

/**
 * 单页 PDF 渲染
 * 每次 pageIndex 变化时会重新执行：
 * 1. 打开 Page → 2. 渲染 Bitmap → 3. 关闭 Page
 * 确保不会泄漏 Page 对象
 */
@Composable
private fun PdfPage(
    renderer: PdfRenderer,
    pageIndex: Int,
    modifier: Modifier = Modifier
) {
    var bitmap by remember(pageIndex) { mutableStateOf<Bitmap?>(null) }
    var isLoading by remember(pageIndex) { mutableStateOf(true) }
    var renderError by remember(pageIndex) { mutableStateOf<String?>(null) }

    LaunchedEffect(pageIndex) {
        isLoading = true
        renderError = null

        var page: PdfRenderer.Page? = null
        try {
            page = renderer.openPage(pageIndex)
            val bmp = Bitmap.createBitmap(
                page.width.coerceAtLeast(1),
                page.height.coerceAtLeast(1),
                Bitmap.Config.ARGB_8888
            )
            page.render(bmp, null, null, PdfRenderer.Page.RENDER_MODE_FOR_DISPLAY)
            bitmap = bmp
        } catch (e: Exception) {
            renderError = "渲染失败: ${e.message}"
        } finally {
            page?.close() // 立即关闭，不缓存
            isLoading = false
        }
    }

    Box(modifier = modifier, contentAlignment = Alignment.Center) {
        when {
            isLoading -> {
                androidx.compose.material3.CircularProgressIndicator(
                    modifier = Modifier.size(32.dp),
                    strokeWidth = 2.dp
                )
            }
            renderError != null -> {
                Text(
                    renderError!!,
                    color = androidx.compose.ui.graphics.Color.Red,
                    style = androidx.compose.material3.MaterialTheme.typography.bodySmall
                )
            }
            bitmap != null -> {
                androidx.compose.foundation.Image(
                    painter = BitmapPainter(bitmap!!.asImageBitmap()),
                    contentDescription = "PDF 第 ${pageIndex + 1} 页",
                    modifier = Modifier.fillMaxSize(),
                    contentScale = ContentScale.Fit
                )
            }
        }
    }
}
