package com.example.noteapp.ui.screen

import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.lifecycle.viewmodel.compose.viewModel
import com.example.noteapp.ui.viewmodel.NoteViewModel

@OptIn(ExperimentalMaterial3Api::class, ExperimentalFoundationApi::class)
@Composable
fun TrashScreen(
    viewModel: NoteViewModel = viewModel(),
    onBack: () -> Unit
) {
    val deletedNotes by viewModel.deletedNotes.collectAsState()
    val selectedIds by viewModel.selectedIds.collectAsState()
    var selectionMode by remember { mutableStateOf(false) }

    Scaffold(
        topBar = {
            if (selectionMode) {
                TopAppBar(
                    title = { Text("已选择 ${selectedIds.size} 项") },
                    navigationIcon = {
                        IconButton(onClick = {
                            selectionMode = false
                            viewModel.clearSelection()
                        }) { Icon(Icons.Default.Close, "取消") }
                    },
                    actions = {
                        IconButton(onClick = {
                            viewModel.restoreSelected()
                            selectionMode = false
                        }) { Icon(Icons.Default.Restore, "恢复") }
                        IconButton(onClick = {
                            viewModel.deleteSelectedPermanently()
                            selectionMode = false
                        }) { Icon(Icons.Default.DeleteForever, "永久删除") }
                    }
                )
            } else {
                TopAppBar(
                    title = { Text("回收站") },
                    navigationIcon = {
                        IconButton(onClick = onBack) {
                            Icon(Icons.AutoMirrored.Filled.ArrowBack, "返回")
                        }
                    },
                    actions = {
                        IconButton(onClick = { selectionMode = true }) {
                            Icon(Icons.Default.CheckCircleOutline, "选择")
                        }
                    }
                )
            }
        }
    ) { padding ->
        if (deletedNotes.isEmpty()) {
            Box(
                modifier = Modifier.fillMaxSize().padding(padding),
                contentAlignment = Alignment.Center
            ) {
                Text("回收站为空", color = MaterialTheme.colorScheme.outline)
            }
        } else {
            LazyVerticalGrid(
                columns = GridCells.Adaptive(minSize = 160.dp),
                contentPadding = PaddingValues(16.dp),
                verticalArrangement = Arrangement.spacedBy(16.dp),
                horizontalArrangement = Arrangement.spacedBy(16.dp),
                modifier = Modifier.padding(padding)
            ) {
                items(deletedNotes, key = { it.id }) { note ->
                    val isSelected = selectedIds.contains(note.id)
                    Card(
                        modifier = Modifier
                            .fillMaxWidth()
                            .combinedClickable(
                                onClick = {
                                    if (selectionMode) viewModel.toggleSelection(note.id)
                                },
                                onLongClick = {
                                    if (!selectionMode) {
                                        selectionMode = true
                                        viewModel.toggleSelection(note.id)
                                    }
                                }
                            )
                    ) {
                        Column(modifier = Modifier.padding(16.dp)) {
                            Text(
                                note.title.ifEmpty { "未命名" },
                                style = MaterialTheme.typography.titleMedium
                            )
                            Text(
                                note.previewText,
                                style = MaterialTheme.typography.bodySmall,
                                maxLines = 2,
                                modifier = Modifier.padding(vertical = 8.dp)
                            )
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                IconButton(onClick = { viewModel.restoreNote(note) }) {
                                    Icon(
                                        Icons.Default.Restore, "恢复",
                                        tint = MaterialTheme.colorScheme.primary
                                    )
                                }
                                IconButton(onClick = { viewModel.deletePermanently(note) }) {
                                    Icon(
                                        Icons.Default.DeleteForever, "永久删除",
                                        tint = MaterialTheme.colorScheme.error
                                    )
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}
