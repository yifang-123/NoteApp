package com.example.noteapp.ui.screen

import android.net.Uri
import androidx.compose.foundation.layout.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.media3.common.MediaItem
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.ui.PlayerView

/**
 * ExoPlayer 视频播放器（内嵌）
 *
 * 安全设计：
 * - 在 DisposableEffect 中创建和释放 ExoPlayer
 * - 组件离开组合时自动释放资源
 */
@Composable
fun VideoPlayer(
    filePath: String,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    var player by remember { mutableStateOf<ExoPlayer?>(null) }

    DisposableEffect(filePath) {
        val exoPlayer = ExoPlayer.Builder(context).build()
        val mediaItem = MediaItem.fromUri(Uri.fromFile(java.io.File(filePath)))
        exoPlayer.setMediaItem(mediaItem)
        exoPlayer.prepare()
        exoPlayer.playWhenReady = true
        player = exoPlayer

        onDispose {
            exoPlayer.stop()
            exoPlayer.release()
            player = null
        }
    }

    AndroidView(
        factory = { ctx ->
            PlayerView(ctx).apply {
                this.player = player
                useController = true
                controllerShowTimeoutMs = 3000
            }
        },
        update = { view ->
            view.player = player
        },
        modifier = modifier
            .fillMaxWidth()
            .height(240.dp)
    )
}
