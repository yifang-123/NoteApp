package com.example.noteapp.ui.viewmodel

import android.util.Log
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.noteapp.data.local.Note
import com.example.noteapp.data.repository.NoteRepository
import com.example.noteapp.ui.screen.BlockState
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.flow.SharedFlow
import kotlinx.coroutines.launch
import org.json.JSONArray
import javax.inject.Inject

/**
 * 编辑器 ViewModel —— 处理保存意图
 *
 * UI 层不直接调用 Repository，而是通过调用 saveNote() 来请求保存。
 * 保存完成后通过 saveResult 通知 UI。
 */
@HiltViewModel
class EditorViewModel @Inject constructor(
    private val repository: NoteRepository
) : ViewModel() {

    companion object {
        private const val TAG = "EditorViewModel"
    }

    // 保存结果事件流（成功/失败）
    private val _saveResult = MutableSharedFlow<SaveResult>()
    val saveResult: SharedFlow<SaveResult> = _saveResult

    /**
     * 保存笔记
     * @param currentSavedId 当前已保存的笔记 ID（0 表示新建）
     * @param title 标题
     * @param blocks 块状态列表
     * @return 保存后的笔记 ID
     */
    fun saveNote(
        currentSavedId: Long,
        title: String,
        blocks: List<BlockState>
    ): Long {
        if (title.isBlank() && blocks.isEmpty()) return currentSavedId

        val jsonArr = JSONArray()
        blocks.forEach { state ->
            jsonArr.put(state.toData().toJson())
        }

        val previewText = buildPreviewText(blocks)

        val note = Note(
            id = if (currentSavedId == 0L) 0L else currentSavedId,
            title = title.ifEmpty { "未命名" },
            content = jsonArr.toString(),
            previewText = previewText
        )

        var resultId = currentSavedId

        viewModelScope.launch {
            try {
                if (currentSavedId == 0L) {
                    val newId = repository.insert(note)
                    if (newId > 0) {
                        resultId = newId
                        _saveResult.emit(SaveResult.Success(newId))
                    } else {
                        _saveResult.emit(SaveResult.Failure("插入失败"))
                    }
                } else {
                    repository.update(note)
                    _saveResult.emit(SaveResult.Success(currentSavedId))
                }
            } catch (e: Exception) {
                Log.e(TAG, "saveNote failed", e)
                _saveResult.emit(SaveResult.Failure(e.message ?: "未知错误"))
            }
        }

        return resultId
    }

    private fun buildPreviewText(blocks: List<BlockState>): String {
        return buildString {
            blocks.forEach { state ->
                when (state) {
                    is com.example.noteapp.ui.screen.TextBlockState ->
                        append(state.text).append(" ")
                    is com.example.noteapp.ui.screen.HeadingBlockState ->
                        append(state.text).append(" ")
                    is com.example.noteapp.ui.screen.CodeBlockState ->
                        append(state.code).append(" ")
                    is com.example.noteapp.ui.screen.AttachmentBlockState ->
                        append("[${state.base.fileName}]").append(" ")
                    is com.example.noteapp.ui.screen.MindMapBlockState ->
                        append(state.title).append(" ")
                    is com.example.noteapp.ui.screen.BulletListBlockState ->
                        state.items.forEach { append(it).append(" ") }
                    is com.example.noteapp.ui.screen.NumberedListBlockState ->
                        state.items.forEach { append(it).append(" ") }
                    is com.example.noteapp.ui.screen.TodoBlockState ->
                        state.items.forEach { append(it.text).append(" ") }
                }
            }
        }.take(200)
    }

    // ─── 密封结果类 ───────────────────────────────
    sealed class SaveResult {
        data class Success(val noteId: Long) : SaveResult()
        data class Failure(val message: String) : SaveResult()
    }
}
