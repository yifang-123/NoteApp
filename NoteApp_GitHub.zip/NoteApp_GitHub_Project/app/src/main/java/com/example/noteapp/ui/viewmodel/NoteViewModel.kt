package com.example.noteapp.ui.viewmodel

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.noteapp.data.local.Note
import com.example.noteapp.data.local.Tag
import com.example.noteapp.data.repository.NoteRepository
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch
import javax.inject.Inject

@HiltViewModel
class NoteViewModel @Inject constructor(
    private val repository: NoteRepository
) : ViewModel() {

    val allNotes: StateFlow<List<Note>> = repository.allNotes
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val deletedNotes: StateFlow<List<Note>> = repository.deletedNotes
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val allTags: StateFlow<List<Tag>> = repository.getAllTagsFlow()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val recentNotes: StateFlow<List<Note>> = repository.recentNotes
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    private val _selectedIds = MutableStateFlow<Set<Long>>(emptySet())
    val selectedIds: StateFlow<Set<Long>> = _selectedIds.asStateFlow()

    // ─── 选择管理 ───────────────────────────────

    fun toggleSelection(id: Long) {
        _selectedIds.update { current ->
            if (current.contains(id)) current - id else current + id
        }
    }

    fun clearSelection() {
        _selectedIds.value = emptySet()
    }

    // ─── 批量操作 ────────────────────────────────

    fun deleteSelected() = viewModelScope.launch {
        repository.moveNotesToTrash(_selectedIds.value.toList())
        clearSelection()
    }

    fun deleteSelectedPermanently() = viewModelScope.launch {
        repository.deleteNotesPermanently(_selectedIds.value.toList())
        clearSelection()
    }

    fun restoreSelected() = viewModelScope.launch {
        repository.restoreNotes(_selectedIds.value.toList())
        clearSelection()
    }

    fun addTagToSelected(tagName: String) = viewModelScope.launch {
        repository.addTagToNotes(_selectedIds.value.toList(), tagName)
        clearSelection()
    }

    // ─── 单条操作 ───────────────────────────────

    fun insert(note: Note) = viewModelScope.launch { repository.insert(note) }
    fun update(note: Note) = viewModelScope.launch { repository.update(note) }

    suspend fun insertAndGetId(note: Note): Long = repository.insert(note)

    suspend fun getNoteById(id: Long): Note? = repository.getNoteById(id)

    suspend fun searchNotes(query: String): List<Note> = repository.searchNotes(query)

    fun moveToTrash(note: Note) = viewModelScope.launch {
        repository.update(note.copy(isDeleted = true, deletedTime = System.currentTimeMillis()))
    }

    fun restoreNote(note: Note) = viewModelScope.launch {
        repository.update(note.copy(isDeleted = false, deletedTime = 0L))
    }

    fun deletePermanently(note: Note) = viewModelScope.launch {
        repository.deleteById(note.id)
    }

    fun addTagToNote(noteId: Long, tagName: String) = viewModelScope.launch {
        repository.addTagToNote(noteId, tagName)
    }

    fun removeTagFromNote(noteId: Long, tagName: String) = viewModelScope.launch {
        repository.removeTagFromNote(noteId, tagName)
    }

    fun getNotesByTag(tagId: Long): Flow<List<Note>> = repository.getNotesByTagFlow(tagId)

    suspend fun getTagsForNote(noteId: Long): List<Tag> = repository.getTagsForNote(noteId)
}
