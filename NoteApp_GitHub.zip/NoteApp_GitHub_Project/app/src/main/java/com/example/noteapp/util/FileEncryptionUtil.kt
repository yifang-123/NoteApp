package com.example.noteapp.util

import android.content.Context
import android.net.Uri
import android.util.Log
import androidx.security.crypto.EncryptedFile
import androidx.security.crypto.MasterKey
import java.io.File
import java.io.FileOutputStream

/**
 * 文件加密工具 —— AES-256-GCM 加密附件
 *
 * 安全设计：
 * - 加密文件存储在 filesDir/encrypted_attachments/
 * - 临时解密文件存储在 cacheDir/temp_attachments/
 * - 所有资源操作在 finally 中关闭
 * - 启动时清理过期临时文件
 */
object FileEncryptionUtil {

    private const val TAG = "FileEncryptionUtil"
    private const val ENCRYPTED_DIR = "encrypted_attachments"
    private const val TEMP_DIR = "temp_attachments"

    // ─── 加密 ───────────────────────────────────────

    fun encryptAndSave(context: Context, sourceUri: Uri, originalFileName: String): String? {
        return try {
            val masterKey = buildMasterKey(context)
            val encryptedDir = File(context.filesDir, ENCRYPTED_DIR).also { if (!it.exists()) it.mkdirs() }

            // 使用 hash 保证同一文件多次加密产生相同文件名（缓存去重）
            val hash = sourceUri.toString().hashCode().toString(16).take(8)
            val safeName = originalFileName.replace(Regex("[^a-zA-Z0-9._-]"), "_")
            val encryptedFileName = "${hash}_${safeName}.enc"
            val encryptedFile = File(encryptedDir, encryptedFileName)

            // 如果已存在同名加密文件，跳过加密
            if (encryptedFile.exists()) return encryptedFileName

            val encFile = EncryptedFile.Builder(
                context,
                encryptedFile,
                masterKey,
                EncryptedFile.FileEncryptionScheme.AES256_GCM_HKDF_4KB
            ).build()

            context.contentResolver.openInputStream(sourceUri)?.use { input ->
                encFile.openFileOutput().use { output ->
                    input.copyTo(output)
                }
            } ?: return null

            encryptedFileName
        } catch (e: Exception) {
            Log.e(TAG, "encryptAndSave failed", e)
            null
        }
    }

    // ─── 解密 ───────────────────────────────────────

    fun decryptToTemp(context: Context, encryptedFileName: String): String? {
        return try {
            val encryptedDir = File(context.filesDir, ENCRYPTED_DIR)
            val encryptedFile = File(encryptedDir, encryptedFileName)
            if (!encryptedFile.exists()) return null

            val masterKey = buildMasterKey(context)
            val encFile = EncryptedFile.Builder(
                context,
                encryptedFile,
                masterKey,
                EncryptedFile.FileEncryptionScheme.AES256_GCM_HKDF_4KB
            ).build()

            val tempDir = File(context.cacheDir, TEMP_DIR).also { if (!it.exists()) it.mkdirs() }
            val tempFile = File(tempDir, encryptedFileName.removeSuffix(".enc"))

            // 如果 temp 文件已存在且比加密文件旧，重新解密
            if (!tempFile.exists() ||
                tempFile.lastModified() < encryptedFile.lastModified()
            ) {
                encFile.openFileInput().use { input ->
                    FileOutputStream(tempFile).use { output ->
                        input.copyTo(output)
                    }
                }
            }

            tempFile.absolutePath
        } catch (e: Exception) {
            Log.e(TAG, "decryptToTemp failed for $encryptedFileName", e)
            null
        }
    }

    // ─── 删除 ───────────────────────────────────────

    fun deleteEncryptedFile(context: Context, encryptedFileName: String) {
        try {
            val encryptedDir = File(context.filesDir, ENCRYPTED_DIR)
            File(encryptedDir, encryptedFileName).delete()
            // 同时清理对应的 temp 文件
            val tempDir = File(context.cacheDir, TEMP_DIR)
            File(tempDir, encryptedFileName.removeSuffix(".enc")).delete()
        } catch (e: Exception) {
            Log.e(TAG, "deleteEncryptedFile failed", e)
        }
    }

    // ─── 清理 ───────────────────────────────────────

    /**
     * 清理超过指定年龄的临时文件
     * @param maxAgeMs 最大保留时间（毫秒），默认 24 小时
     */
    fun cleanExpiredTempFiles(context: Context, maxAgeMs: Long = 24 * 60 * 60 * 1000L) {
        try {
            val tempDir = File(context.cacheDir, TEMP_DIR)
            if (!tempDir.exists()) return
            val cutoff = System.currentTimeMillis() - maxAgeMs
            tempDir.listFiles()?.forEach { file ->
                if (file.lastModified() < cutoff) {
                    file.delete()
                    Log.d(TAG, "Cleaned expired temp file: ${file.name}")
                }
            }
        } catch (e: Exception) {
            Log.e(TAG, "cleanExpiredTempFiles failed", e)
        }
    }

    /**
     * 清理所有临时文件（应用启动时兜底调用）
     */
    fun cleanAllTempFiles(context: Context) {
        try {
            val tempDir = File(context.cacheDir, TEMP_DIR)
            if (tempDir.exists()) {
                tempDir.listFiles()?.forEach { it.delete() }
            }
        } catch (e: Exception) {
            Log.e(TAG, "cleanAllTempFiles failed", e)
        }
    }

    // ─── 内部工具 ──────────────────────────────────

    private fun buildMasterKey(context: Context): MasterKey {
        return MasterKey.Builder(context)
            .setKeyScheme(MasterKey.KeyScheme.AES256_GCM)
            .build()
    }
}
