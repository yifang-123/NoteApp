package com.example.noteapp.util

import android.content.Context
import android.content.Intent
import android.net.Uri
import androidx.core.content.FileProvider
import java.io.File

/**
 * 文件分享工具 —— 基于 FileProvider 的安全分享
 *
 * 使用方式：
 * - shareFile(context, filePath, mimeType) → 弹出系统分享面板
 * - openWithOtherApp(context, filePath, mimeType) → 弹出"用其他应用打开"
 */
object ShareHelper {

    private const val AUTHORITY_SUFFIX = ".fileprovider"

    /**
     * 通过系统分享面板分享文件
     */
    fun shareFile(context: Context, filePath: String, mimeType: String): Boolean {
        val file = File(filePath)
        if (!file.exists()) return false

        return try {
            val uri = getFileUri(context, file)
            val intent = Intent(Intent.ACTION_SEND).apply {
                type = mimeType
                putExtra(Intent.EXTRA_STREAM, uri)
                addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            }
            val chooser = Intent.createChooser(intent, "分享文件")
            chooser.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            context.startActivity(chooser)
            true
        } catch (e: Exception) {
            false
        }
    }

    /**
     * 用其他应用打开文件（用于 Office 等不支持预览的格式）
     */
    fun openWithOtherApp(context: Context, filePath: String, mimeType: String): Boolean {
        val file = File(filePath)
        if (!file.exists()) return false

        return try {
            val uri = getFileUri(context, file)
            val intent = Intent(Intent.ACTION_VIEW).apply {
                setDataAndType(uri, mimeType)
                addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            }

            // 检查是否有应用可以处理此 Intent
            if (intent.resolveActivity(context.packageManager) != null) {
                context.startActivity(intent)
                true
            } else {
                // 没有可用应用，尝试分享
                shareFile(context, filePath, mimeType)
            }
        } catch (e: Exception) {
            false
        }
    }

    /**
     * 获取文件的 Content URI（通过 FileProvider）
     */
    private fun getFileUri(context: Context, file: File): Uri {
        val authority = "${context.packageName}$AUTHORITY_SUFFIX"
        return FileProvider.getUriForFile(context, authority, file)
    }
}
