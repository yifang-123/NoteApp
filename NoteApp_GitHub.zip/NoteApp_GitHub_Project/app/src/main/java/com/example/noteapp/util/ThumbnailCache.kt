package com.example.noteapp.util

import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.pdf.PdfRenderer
import android.os.ParcelFileDescriptor
import java.io.File
import java.lang.ref.WeakReference

/**
 * 缩略图缓存 —— 基于 LruCache
 *
 * 安全设计：
 * - 淘汰时调用 bitmap.recycle() 释放 native 内存
 * - 覆盖旧值时回收旧 bitmap
 * - 所有 IO 操作在 finally 中关闭资源
 */
object ThumbnailCache {

    private const val MAX_CACHE_SIZE = 32 * 1024 * 1024  // 32MB

    private val cache: android.util.LruCache<String, WeakReference<Bitmap>> =
        object : android.util.LruCache<String, WeakReference<Bitmap>>(MAX_CACHE_SIZE) {
            override fun sizeOf(key: String, value: WeakReference<Bitmap>): Int {
                val bmp = value.get()
                return if (bmp != null && !bmp.isRecycled) {
                    bmp.allocationByteCount.coerceAtLeast(1)
                } else {
                    1
                }
            }

            override fun entryRemoved(
                evicted: Boolean,
                key: String,
                oldValue: WeakReference<Bitmap>,
                newValue: WeakReference<Bitmap>?
            ) {
                // 回收被淘汰的 bitmap
                oldValue.get()?.let { bmp ->
                    if (!bmp.isRecycled) {
                        bmp.recycle()
                    }
                }
            }
        }

    fun get(key: String): Bitmap? {
        val ref = cache[key] ?: return null
        val bmp = ref.get()
        if (bmp == null || bmp.isRecycled) {
            cache.remove(key)
            return null
        }
        return bmp
    }

    fun put(key: String, bitmap: Bitmap) {
        // 覆盖旧值时回收
        cache[key]?.get()?.let { old ->
            if (!old.isRecycled) old.recycle()
        }
        cache.put(key, WeakReference(bitmap))
    }

    fun clear() {
        cache.evictAll()
    }

    // ─── 缩略图生成（后台线程调用） ───────────────

    /**
     * 生成图片缩略图
     * 必须在 IO 线程调用
     */
    fun createImageThumbnail(file: File, maxWidth: Int = 400, maxHeight: Int = 400): Bitmap? {
        if (!file.exists()) return null
        return try {
            val opts = BitmapFactory.Options().apply {
                inJustDecodeBounds = true
            }
            BitmapFactory.decodeFile(file.absolutePath, opts)

            val scale = maxOf(
                opts.outWidth / maxWidth,
                opts.outHeight / maxHeight,
                1
            )
            opts.apply {
                inJustDecodeBounds = false
                inSampleSize = scale
                inPreferredConfig = Bitmap.Config.ARGB_8888
            }
            BitmapFactory.decodeFile(file.absolutePath, opts)
        } catch (e: Exception) {
            null
        }
    }

    /**
     * 生成 PDF 首页缩略图
     * 必须在 IO 线程调用
     * 所有资源在 finally 中关闭
     */
    fun createPdfThumbnail(
        file: File,
        maxWidth: Int = 400,
        maxHeight: Int = 400
    ): Bitmap? {
        if (!file.exists()) return null

        var fd: ParcelFileDescriptor? = null
        var renderer: PdfRenderer? = null
        var page: PdfRenderer.Page? = null

        return try {
            fd = ParcelFileDescriptor.open(file, ParcelFileDescriptor.MODE_READ_ONLY)
            renderer = PdfRenderer(fd)

            if (renderer.pageCount == 0) return null

            page = renderer.openPage(0)

            // 计算缩放
            val scaleX = maxWidth.toFloat() / page.width
            val scaleY = maxHeight.toFloat() / page.height
            val scale = minOf(scaleX, scaleY, 1f)

            val width = (page.width * scale).toInt().coerceAtLeast(1)
            val height = (page.height * scale).toInt().coerceAtLeast(1)

            val bitmap = Bitmap.createBitmap(width, height, Bitmap.Config.ARGB_8888)
            page.render(bitmap, null, null, PdfRenderer.Page.RENDER_MODE_FOR_DISPLAY)
            bitmap
        } catch (e: Exception) {
            null
        } finally {
            page?.close()
            renderer?.close()
            fd?.close()
        }
    }
}
