package com.example.noteapp.widget;

import android.content.Context
import androidx.work.*
import com.example.noteapp.util.FileEncryptionUtil
import dagger.assisted.Assisted
import dagger.assisted.AssistedInject
import java.util.concurrent.TimeUnit

/**
 * 定期清理过期临时文件的 Worker
 * 每天执行一次，清理超过 24 小时的临时文件
 */
@HiltWorker
class CleanupWorker @AssistedInject constructor(
    @Assisted context: Context,
    @Assisted workerParams: WorkerParameters
) : CoroutineWorker(context, workerParams) {

    override suspend fun doWork(): Result {
        return try {
            FileEncryptionUtil.cleanExpiredTempFiles(
                applicationContext,
                maxAgeMs = 24 * 60 * 60 * 1000L
            )
            Result.success()
        } catch (e: Exception) {
            if (runAttemptCount < 3) Result.retry() else Result.failure()
        }
    }

    companion object {
        private const val WORK_NAME = "temp_file_cleanup"

        fun enqueuePeriodic(context: Context) {
            val request = PeriodicWorkRequestBuilder<CleanupWorker>(
                1, TimeUnit.DAYS
            ).setConstraints(
                Constraints.Builder()
                    .setRequiredNetworkType(NetworkType.NOT_REQUIRED)
                    .build()
            ).build()

            WorkManager.getInstance(context).enqueueUniquePeriodicWork(
                WORK_NAME,
                ExistingPeriodicWorkPolicy.KEEP,
                request
            )
        }
    }
}
