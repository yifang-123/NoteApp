package com.example.noteapp.widget

import android.content.Context
import android.util.Log
import androidx.compose.runtime.Composable
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.glance.*
import androidx.glance.action.actionStartActivity
import androidx.glance.action.clickable
import androidx.glance.appwidget.GlanceAppWidget
import androidx.glance.appwidget.GlanceAppWidgetManager
import androidx.glance.appwidget.GlanceAppWidgetReceiver
import androidx.glance.appwidget.cornerRadius
import androidx.glance.appwidget.provideContent
import androidx.glance.layout.*
import androidx.glance.text.Text
import androidx.glance.text.TextStyle
import androidx.glance.text.FontWeight
import com.example.noteapp.MainActivity
import com.example.noteapp.data.repository.NoteRepository
import dagger.hilt.EntryPoint
import dagger.hilt.InstallIn
import dagger.hilt.components.SingletonComponent
import dagger.hilt.EntryPoints
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONArray

@EntryPoint
@InstallIn(SingletonComponent::class)
interface NoteRepositoryEntryPoint {
    fun repository(): NoteRepository
}

class NoteWidget : GlanceAppWidget() {

    companion object {
        private const val TAG = "NoteWidget"
        private const val PREFS_NAME = "note_widget_prefs"
        private const val KEY_JSON = "recent_notes_json"
        private const val KEY_LOADING = "is_loading"

        suspend fun updateJsonWidget(context: Context) {
            val glanceId = GlanceAppWidgetManager(context)
                .getGlanceIds(NoteWidget::class.java)
                .firstOrNull() ?: return
            try {
                val entryPoint = EntryPoints.get(
                    context.applicationContext,
                    NoteRepositoryEntryPoint::class.java
                )
                val repo = entryPoint.repository()
                val notes = withContext(Dispatchers.IO) { repo.getRecentNotes() }

                val jsonArr = JSONArray()
                notes.forEach { n ->
                    val obj = org.json.JSONObject()
                    obj.put("title", n.title)
                    obj.put("preview", n.previewText)
                    jsonArr.put(obj)
                }

                context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
                    .edit()
                    .putString(KEY_JSON, jsonArr.toString())
                    .putBoolean(KEY_LOADING, false)
                    .apply()

                NoteWidget().update(context, glanceId)
            } catch (e: Exception) {
                Log.e(TAG, "更新失败", e)
            }
        }
    }

    override suspend fun provideGlance(context: Context, id: GlanceId) {
        provideContent { Content(context) }
    }

    @Composable
    private fun Content(context: Context) {
        val prefs = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
        val isLoading = prefs.getBoolean(KEY_LOADING, true)
        val jsonStr = prefs.getString(KEY_JSON, "[]") ?: "[]"
        val list = try {
            val arr = JSONArray(jsonStr)
            (0 until arr.length()).map { i ->
                val obj = arr.getJSONObject(i)
                obj.optString("title") to obj.optString("preview")
            }
        } catch (_: Exception) { emptyList() }

        Column(
            modifier = GlanceModifier.fillMaxSize().padding(16.dp)
                .background(GlanceTheme.colors.surface).cornerRadius(16.dp),
            verticalAlignment = Alignment.Top,
            horizontalAlignment = Alignment.Start
        ) {
            Row(
                modifier = GlanceModifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "最近笔记",
                    style = TextStyle(
                        color = GlanceTheme.colors.onSurface,
                        fontSize = 16.sp,
                        fontWeight = FontWeight.Bold
                    )
                )
                Spacer(GlanceModifier.width(8.dp))
                Text(
                    text = "新建",
                    style = TextStyle(
                        color = GlanceTheme.colors.primary,
                        fontSize = 14.sp
                    ),
                    modifier = GlanceModifier.clickable(
                        actionStartActivity(MainActivity::class.java)
                    )
                )
            }
            Spacer(GlanceModifier.height(12.dp))
            when {
                isLoading -> {
                    Text(
                        text = "加载中...",
                        style = TextStyle(
                            color = GlanceTheme.colors.onSurfaceVariant,
                            fontSize = 14.sp
                        )
                    )
                }
                list.isEmpty() -> {
                    Text(
                        text = "暂无笔记，点击新建",
                        style = TextStyle(
                            color = GlanceTheme.colors.onSurfaceVariant,
                            fontSize = 14.sp
                        )
                    )
                }
                else -> {
                    list.forEach { (title, preview) ->
                        Column(modifier = GlanceModifier.padding(vertical = 4.dp)) {
                            Text(
                                text = title.ifEmpty { "未命名" },
                                style = TextStyle(
                                    color = GlanceTheme.colors.onSurface,
                                    fontSize = 14.sp,
                                    fontWeight = FontWeight.Medium
                                ),
                                maxLines = 1
                            )
                            Text(
                                text = preview.ifEmpty { "无内容" },
                                style = TextStyle(
                                    color = GlanceTheme.colors.onSurfaceVariant,
                                    fontSize = 12.sp
                                ),
                                maxLines = 1
                            )
                        }
                    }
                }
            }
        }
    }
}

class NoteWidgetReceiver : GlanceAppWidgetReceiver() {
    override val glanceAppWidget: GlanceAppWidget = NoteWidget()
}
